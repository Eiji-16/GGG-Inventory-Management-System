import { useCallback, useEffect, useLayoutEffect, useState, useRef } from 'react';
import { createPortal } from 'react-dom';
import {
  LayoutDashboard,
  Users,
  Boxes,
  TrendingUp,
  BarChart3,
  LogOut,
  Bell,
  BellOff,
  AlertTriangle,
  PackageCheck,
  TrendingUp as TrendUpIcon,
  Info,
  Check,
  User,
  Menu,
  X,
  UsersRound,
  Settings as SettingsIcon,
  BellRing,
  CircleUserRound,
  Camera,
  Trash2,
  PanelLeft,
} from 'lucide-react'; /* ===== ICONS ===== */

import './landingPage.css'; /* ===== STYLES ===== */
import apiFetch from '../../apiFetch';
import { SAFETY_STOCK_DEFAULTS, DEFAULT_SAFETY_STOCK, reorderPointFor, safetyPointFor, statusPointsFor } from '../../data/safetyStock'; /* ===== POLICY ===== */
import Dashboard from '../Dashboard/dashboard'; /* ===== DASHBOARD ===== */
import ProductSupplier from '../ProductSupplier/productSupplier'; /* ===== PRODUCTS ===== */
import SalesForecasting from '../Forecasting/forecasting'; /* ===== FORECASTING ===== */
import ReportAnalytics from '../Reports/reports'; /* ===== REPORTS ===== */
import StockManagement from '../StockControl/stockControl'; /* ===== STOCK ===== */
import ReorderAlerts from '../ReorderAlerts/reorderAlerts'; /* ===== REORDER ALERTS ===== */
import Settings from '../Settings/Settings'; /* ===== SETTINGS ===== */
import Profile from '../Profile/profile'; /* ===== PROFILE ===== */
import Staffs from '../Staffs/staffs'; /* ===== STAFFS ===== */
import TrashBin from '../TrashBin/trashBin'; /* ===== TRASH BIN & ARCHIVE ===== */
import { removePlainBackground } from '../../utils/removePlainBackground'; /* ===== LOGO BACKGROUND ===== */

/* ===== NOTIFICATION ICONS ===== */
const NOTIF_ICONS = {
  critical: { Icon: AlertTriangle, cls: 'notif-ic-critical' },
  warning:  { Icon: AlertTriangle, cls: 'notif-ic-warning' },
  forecast: { Icon: TrendUpIcon,   cls: 'notif-ic-forecast' },
  success:  { Icon: PackageCheck,  cls: 'notif-ic-success' },
  info:     { Icon: Info,          cls: 'notif-ic-info' },
};

function formatNotificationTime(timestamp) {
  if (!timestamp) return 'Recently';
  const elapsed = Math.max(0, Date.now() - new Date(timestamp).getTime());
  if (!Number.isFinite(elapsed)) return 'Recently';
  const minutes = Math.floor(elapsed / 60000);
  if (minutes < 1) return 'Just now';
  if (minutes < 60) return `${minutes} min ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} hour${hours === 1 ? '' : 's'} ago`;
  const days = Math.floor(hours / 24);
  return `${days} day${days === 1 ? '' : 's'} ago`;
}

function mapSafetyStockPolicies(records) {
  return Object.fromEntries(records.map((record) => {
    const defaults = record.configured ? {} : SAFETY_STOCK_DEFAULTS[record.productName] || {};
    return [record.productId, {
      productName: record.productName,
      safetyStock: record.safetyStock ?? defaults.safetyStock ?? DEFAULT_SAFETY_STOCK,
      leadTimeDays: record.leadTimeDays ?? defaults.leadTimeDays ?? '',
      // Status points: 'auto' (reorder point / safety stock) or 'manual'.
      statusMode: record.statusMode || 'manual',
      lowPoint: record.lowPoint ?? '',
      criticalPoint: record.criticalPoint ?? '',
      // Read-only context for the Settings preview (not saved by the policy).
      category: record.category || '',
      brand: record.brand || '',
      model: record.model || '',
      supplierName: record.supplierName || '',
      supplierLeadTimeDays: record.supplierLeadTimeDays ?? null,
      demandFromHistory: record.demandFromHistory ?? 0,
      orderingCost: record.orderingCost ?? defaults.orderingCost ?? '',
      holdingCost: record.holdingCost ?? defaults.holdingCost ?? '',
      configured: record.configured,
    }];
  }));
}

function eoqHandoffStorageKey(userId) {
  return `ggg-inventory-forecast-eoq:${userId}`;
}

function readSavedEoqHandoff(userId) {
  if (!userId || typeof window === 'undefined') return null;
  try {
    const saved = window.sessionStorage.getItem(eoqHandoffStorageKey(userId));
    if (!saved) return null;
    const handoff = JSON.parse(saved);
    if (
      handoff?.type !== 'forecast-eoq'
      || !handoff.productId
      || !Number.isFinite(Number(handoff.annualDemand))
      || !Number.isFinite(Number(handoff.baseForecast))
      || !Number.isFinite(Number(handoff.adjustedForecast))
      || !['week', 'month', 'year'].includes(handoff.periodType)
      || !handoff.forecastPeriod
    ) {
      window.sessionStorage.removeItem(eoqHandoffStorageKey(userId));
      return null;
    }
    return handoff;
  } catch (error) {
    console.error('Could not restore the forecast EOQ handoff:', error);
    return null;
  }
}

/* Bell items = reorder alerts. Same rule as the Dashboard "Reorder Alerts"
   card, the sidebar badge and the Reorder Alerts page: a product that has
   at least one stock entry and is at or below its low point. (Staff restock
   requests are added to the bell separately.) */
function createNotifications(summary, policy) {
  const notifications = [];
  (summary.products || []).forEach((product) => {
    if (product.inStockControl === false) return; // no stock entries yet
    const stock = Number(product.stock) || 0;
    const reorderPoint = reorderPointFor({
      productId: product.id,
      productName: product.name,
      safetyStock: product.safetyStock,
      annualDemand: product.annualDemand,
      leadTimeDays: product.leadTimeDays,
    }, policy);
    // Same status points as everywhere else (Automatic or Manual).
    const row = { productId: product.id, productName: product.name, safetyStock: product.safetyStock, annualDemand: product.annualDemand, leadTimeDays: product.leadTimeDays };
    const points = statusPointsFor(row, policy);
    if (stock > points.low) return;
    const safety = safetyPointFor(row, policy);
    const level = stock <= 0 ? 'out' : stock <= points.critical ? 'critical' : 'low';
    notifications.push({
      id: `stock-${product.id}-${level}`,
      type: level === 'low' ? 'warning' : 'critical',
      title: {
        out: `${product.name} is out of stock`,
        critical: `${product.name} is critically low`,
        low: `${product.name} is running low`,
      }[level],
      meta: level === 'low'
        ? `${stock} on hand · low at ${points.low} — time to order`
        : `${stock} on hand · critical at ${points.critical} · safety stock ${safety} · reorder point ${reorderPoint}`,
      time: 'Current stock',
      view: 'Reorder-Alerts',
      read: false,
      // For the visual row in the bell: product, level, stock vs reorder point.
      kind: 'stock',
      product: product.name,
      level,
      stock,
      reorderPoint,
    });
  });

  // "Stock in/out recorded" notices are no longer added: they made the bell
  // number bigger than the Reorder Alerts count. Recent entries are still on
  // the Dashboard and in Stock Control's activity history.

  return notifications;
}

function loadNotificationPreference(key) {
  try {
    const saved = JSON.parse(localStorage.getItem(key) || '{}');
    return {
      readIds: Array.isArray(saved.readIds) ? saved.readIds.filter((id) => typeof id === 'string') : [],
      dismissedIds: Array.isArray(saved.dismissedIds) ? saved.dismissedIds.filter((id) => typeof id === 'string') : [],
    };
  } catch (error) {
    console.error('Could not load notification preferences:', error);
    return { readIds: [], dismissedIds: [] };
  }
}

function LandingPage({onLogout, onSessionRevoked, user, theme, onThemeChange}) {
  /* ===== ROLE ACCESS =====
     Which pages and buttons this account may use. The Super Admin sets the
     boxes in Settings → Role Access; the server sends the result as
     user.permissions and checks the same boxes on every action.
     Dashboard, Profile and Settings are always open; Staffs is Super Admin only. */
  const role = user?.role || 'staff';
  const isSuperAdminRole = role === 'super_admin' || user?.isSuperAdmin === true;
  const [permissions, setPermissions] = useState(() => user?.permissions || {});
  useEffect(() => { setPermissions(user?.permissions || {}); }, [user?.permissions]);

  /* Pick up changes the Super Admin makes while this account is signed in. */
  const refreshPermissions = useCallback(async () => {
    try {
      const response = await fetch('/api/role-access', { headers: { Accept: 'application/json' }, cache: 'no-store' });
      if (!response.ok) return;
      const body = await response.json();
      if (body?.permissions) setPermissions(body.permissions);
    } catch {
      /* keep the last known permissions */
    }
  }, []);
  useEffect(() => {
    const timer = window.setInterval(refreshPermissions, 60000);
    window.addEventListener('focus', refreshPermissions);
    return () => {
      window.clearInterval(timer);
      window.removeEventListener('focus', refreshPermissions);
    };
  }, [refreshPermissions]);

  const can = (key) => isSuperAdminRole || permissions?.[key] === true;
  const VIEW_PERMISSION = {
    'Product-Supplier': 'products.view',
    Stock:              'stock.view',
    'Reorder-Alerts':   'reorder.view',
    'Auto-Calculator':  'calculator.use',
    Forecasting:        'forecast.view',
    Reports:            'reports.view',
  };
  const canAccess = (view) => {
    if (view === 'Dashboard' || view === 'Profile' || view === 'Setting') return true;
    // Super Admin, or an Admin with Role Access "Manage Staff" (Staff accounts only).
    if (view === 'Staffs') return isSuperAdminRole || (role === 'admin' && can('staff.manage'));
    if (view === 'Trash-Archive') return isSuperAdminRole;
    const key = VIEW_PERMISSION[view];
    return key ? can(key) : false;
  };

  /* Settings expects a display-style role name and shows the Safety Stock
     section only for 'Super Admin'. Map the backend role to that label. */
  const roleLabel = { super_admin: 'Super Admin', admin: 'Admin', staff: 'Staff' }[role] || 'Staff';

  const [isSidebarOpen, setIsSidebarOpen] = useState(false); /* ===== SIDEBAR ===== */
  /* Desktop sidebar: icons only (default) or icons with names. The choice is
     saved in this browser. Phones keep their own slide-in menu. */
  const [sidebarExpanded, setSidebarExpanded] = useState(() => {
    try { return localStorage.getItem('ggg-sidebar-mode') === 'labels'; } catch { return false; }
  });
  const toggleSidebarMode = () => {
    setSidebarExpanded((expanded) => {
      const next = !expanded;
      try { localStorage.setItem('ggg-sidebar-mode', next ? 'labels' : 'icons'); } catch { /* storage blocked */ }
      return next;
    });
  };
  // Tables that fill the screen measure again once the sidebar has resized.
  useEffect(() => {
    const timer = window.setTimeout(() => window.dispatchEvent(new Event('resize')), 300);
    return () => window.clearTimeout(timer);
  }, [sidebarExpanded]);
  const [isLogoutConfirmOpen, setIsLogoutConfirmOpen] = useState(false);

  /* ===== SIDEBAR PICTURE =====
     Default: a profile icon. The Super Admin can choose a picture that every
     account then sees (saved on the server, see SystemLogoController). */
  const isSuperAdminUser = isSuperAdminRole;
  const [logoUrl, setLogoUrl] = useState(user?.logoUrl || null);
  // Own profile photo in the sidebar account row (null = initials).
  const [avatarUrl, setAvatarUrl] = useState(user?.avatarUrl || null);
  useEffect(() => {
    const onChange = (event) => setAvatarUrl(event.detail || null);
    window.addEventListener('ggg-avatar-changed', onChange);
    return () => window.removeEventListener('ggg-avatar-changed', onChange);
  }, []);
  const [isLogoModalOpen, setIsLogoModalOpen] = useState(false);
  const [logoBusy, setLogoBusy] = useState(false);
  const [logoError, setLogoError] = useState('');
  const logoFileRef = useRef(null);
  useEffect(() => { setLogoUrl(user?.logoUrl || null); }, [user?.logoUrl]);

  /* ===== LOGO PREVIEW + "REMOVE PLAIN BACKGROUND" (2026-11-06) =====
     Choosing a picture shows a preview first (on a checkered background so
     see-through parts are visible). The switch removes one plain colour
     around the logo (src/utils/removePlainBackground.js); Strength sets how
     much. "Save logo" uploads what the preview shows. */
  const [logoDraft, setLogoDraft] = useState(null);        // { file, url }
  const [logoRemoveBg, setLogoRemoveBg] = useState(false);
  const [logoBgStrength, setLogoBgStrength] = useState(40);
  const [logoCleaned, setLogoCleaned] = useState(null);    // { blob, url, removed, alreadyClear }
  const [logoCleaning, setLogoCleaning] = useState(false);

  const clearLogoDraft = () => {
    setLogoDraft((draft) => { if (draft?.url) URL.revokeObjectURL(draft.url); return null; });
    setLogoCleaned((cleaned) => { if (cleaned?.url) URL.revokeObjectURL(cleaned.url); return null; });
    setLogoRemoveBg(false);
    setLogoBgStrength(40);
  };

  useEffect(() => {
    if (!logoDraft || !logoRemoveBg) return undefined;
    let cancelled = false;
    setLogoCleaning(true);
    const timer = window.setTimeout(async () => {
      try {
        const result = await removePlainBackground(logoDraft.file, { tolerance: logoBgStrength });
        if (cancelled) { URL.revokeObjectURL(result.url); return; }
        setLogoCleaned((previous) => { if (previous?.url) URL.revokeObjectURL(previous.url); return result; });
        setLogoError('');
      } catch (error) {
        if (!cancelled) setLogoError(error.message || 'The background could not be removed.');
      } finally {
        if (!cancelled) setLogoCleaning(false);
      }
    }, 150);   // wait until the Strength slider stops moving
    return () => { cancelled = true; window.clearTimeout(timer); };
  }, [logoDraft, logoRemoveBg, logoBgStrength]);

  const closeLogoModal = () => {
    if (logoBusy) return;
    setIsLogoModalOpen(false);
    setLogoError('');
    clearLogoDraft();
  };

  // Step 1: a picture was chosen — check it and show the preview.
  const pickLogo = (event) => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setLogoError('Please choose an image file (JPG, PNG, WEBP or GIF).');
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      setLogoError('The picture must be 2 MB or smaller.');
      return;
    }
    setLogoError('');
    clearLogoDraft();
    setLogoDraft({ file, url: URL.createObjectURL(file) });
  };

  // Step 2: "Save logo" — upload the original, or the see-through PNG.
  const uploadLogo = async () => {
    if (!logoDraft) return;
    const useCleaned = logoRemoveBg && logoCleaned && !logoCleaned.alreadyClear;
    const file = useCleaned
      ? new File([logoCleaned.blob], 'logo.png', { type: 'image/png' })
      : logoDraft.file;
    if (file.size > 2 * 1024 * 1024) {
      setLogoError('The picture must be 2 MB or smaller.');
      return;
    }
    setLogoBusy(true);
    setLogoError('');
    try {
      const form = new FormData();
      form.append('logo', file);
      const response = await apiFetch('/branding/logo', { method: 'POST', body: form });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw new Error(Object.values(body?.errors || {}).flat()[0] || body?.message || `Upload failed (${response.status}).`);
      }
      setLogoUrl(body.logoUrl || null);
      setIsLogoModalOpen(false);
      clearLogoDraft();
    } catch (error) {
      setLogoError(error.message || 'The picture could not be saved.');
    } finally {
      setLogoBusy(false);
    }
  };

  const removeLogo = async () => {
    setLogoBusy(true);
    setLogoError('');
    try {
      const response = await apiFetch('/branding/logo', { method: 'DELETE' });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body?.message || `Remove failed (${response.status}).`);
      setLogoUrl(null);
      setIsLogoModalOpen(false);
    } catch (error) {
      setLogoError(error.message || 'The picture could not be removed.');
    } finally {
      setLogoBusy(false);
    }
  };

  const logoContent = logoUrl
    ? <img className="sidebar-logo-img" src={logoUrl} alt="" onError={() => setLogoUrl(null)} />
    : <CircleUserRound className="sidebar-logo-icon" aria-hidden="true" />;
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const logoutProcessingRef = useRef(false);
  const logoutCancelRef = useRef(null);
  const [activeView, setActiveView] = useState('Dashboard'); /* ===== ACTIVE VIEW ===== */
  const [visitedViews, setVisitedViews] = useState(() => new Set(['Dashboard']));
  /* If the Super Admin switches off the page this account is on, go back to the Dashboard. */
  const activeViewAllowed = canAccess(activeView);
  useEffect(() => {
    if (!activeViewAllowed) setActiveView('Dashboard');
  }, [activeViewAllowed]);
  const mainContentRef = useRef(null);
  const viewScrollPositions = useRef({});
  const [handoff, setHandoff] = useState(() => readSavedEoqHandoff(user?.id)); /* ===== HANDOFF ===== */
  const [safetyStock, setSafetyStock] = useState(SAFETY_STOCK_DEFAULTS); /* ===== SAFETY STOCK ===== */
  const [policyLoading, setPolicyLoading] = useState(true);
  const [policyError, setPolicyError] = useState('');
  const [policyRefreshKey, setPolicyRefreshKey] = useState(0);
  /* Goes up whenever someone changes data on any computer (see AUTO-REFRESH). */
  const [dataRevision, setDataRevision] = useState(0);
  const [notifications, setNotifications] = useState([]); /* ===== NOTIFICATION STATE ===== */
  const [reorderAlertCount, setReorderAlertCount] = useState(0); /* ===== SIDEBAR BADGE ===== */
  const notificationPreferenceKey = `ggg-inventory-notifications:${user?.id ?? user?.email ?? 'account'}`;
  const notificationPreferencesRef = useRef(null);
  const notificationPreferenceOwnerRef = useRef(notificationPreferenceKey);
  if (notificationPreferenceOwnerRef.current !== notificationPreferenceKey) {
    notificationPreferenceOwnerRef.current = notificationPreferenceKey;
    notificationPreferencesRef.current = null;
  }
  if (notificationPreferencesRef.current === null) {
    notificationPreferencesRef.current = loadNotificationPreference(notificationPreferenceKey);
  }
  const [notificationsLoading, setNotificationsLoading] = useState(true);
  const [notificationError, setNotificationError] = useState('');
  const [isNotifOpen, setIsNotifOpen] = useState(false); /* ===== NOTIFICATION MENU ===== */
  const notifRef = useRef(null); /* ===== NOTIFICATION REF ===== */

  const unreadCount = notifications.filter((n) => !n.read).length;
  /* Red number on the bell = every current reorder alert (read or not, so it
     always matches the Dashboard card and Reorder Alerts) + unread restock
     requests from Staff. */
  const unreadRequestCount = notifications.filter((n) => (n.id.startsWith('request-') || n.id.startsWith('account-')) && !n.read).length;
  const bellCount = reorderAlertCount + unreadRequestCount;

  useEffect(() => {
    if (!isLogoutConfirmOpen) return undefined;
    logoutCancelRef.current?.focus();
    const closeOnEscape = (event) => {
      if (event.key === 'Escape' && !logoutProcessingRef.current) {
        setIsLogoutConfirmOpen(false);
      }
    };
    document.addEventListener('keydown', closeOnEscape);
    return () => document.removeEventListener('keydown', closeOnEscape);
  }, [isLogoutConfirmOpen]);

  const saveNotificationPreferences = (next) => {
    notificationPreferencesRef.current = next;
    try {
      localStorage.setItem(notificationPreferenceKey, JSON.stringify(next));
    } catch (error) {
      console.error('Could not save notification preferences:', error);
    }
  };

  /* ===== DASHBOARD SUMMARY (shared) =====
     The bell and the Dashboard both need /api/dashboard/summary. When they
     ask at the same moment (e.g. right after login), they share one request
     instead of loading it twice. */
  const summaryRequestRef = useRef({ promise: null, at: 0 });
  const fetchDashboardSummary = useCallback(() => {
    const shared = summaryRequestRef.current;
    if (shared.promise && Date.now() - shared.at < 3000) return shared.promise;
    const promise = fetch('/api/dashboard/summary', { headers: { Accept: 'application/json' }, cache: 'no-store' })
      .then((response) => {
        if (!response.ok) {
          const error = new Error(`Request failed (${response.status}).`);
          error.status = response.status;
          throw error;
        }
        return response.json();
      });
    summaryRequestRef.current = { promise, at: Date.now() };
    // A failed request is not shared: the next ask tries again.
    promise.catch(() => {
      if (summaryRequestRef.current.promise === promise) summaryRequestRef.current = { promise: null, at: 0 };
    });
    return promise;
  }, []);

  useEffect(() => {
    if (policyLoading) return undefined;
    let active = true;
    fetchDashboardSummary()
      .catch((error) => {
        throw new Error(`Could not load notifications (${error.status ?? 'network'}).`);
      })
      .then((summary) => {
        if (!active) return;
        const current = createNotifications(summary, safetyStock);
        setReorderAlertCount(current.filter((notification) => notification.id.startsWith('stock-')).length);
        const activeStockIds = new Set(current
          .filter((notification) => notification.id.startsWith('stock-'))
          .map((notification) => notification.id));
        const previous = notificationPreferencesRef.current;
        const next = {
          readIds: previous.readIds.filter((id) => !id.startsWith('stock-') || activeStockIds.has(id)),
          dismissedIds: previous.dismissedIds.filter((id) => !id.startsWith('stock-') || activeStockIds.has(id)),
        };
        if (
          next.readIds.length !== previous.readIds.length
          || next.dismissedIds.length !== previous.dismissedIds.length
        ) {
          saveNotificationPreferences(next);
        }
        const readIds = new Set(next.readIds);
        const dismissedIds = new Set(next.dismissedIds);
        const stockItems = current
          .filter((notification) => !dismissedIds.has(notification.id))
          .map((notification) => ({ ...notification, read: readIds.has(notification.id) }));
        // Keep restock requests (loaded separately below) at the top.
        setNotifications((previous) => [
          ...previous.filter((notification) => notification.id.startsWith('request-') || notification.id.startsWith('account-')),
          ...stockItems,
        ]);
      })
      .catch((error) => {
        if (active) setNotificationError(error.message || 'Could not load notifications.');
      })
      .finally(() => {
        if (active) setNotificationsLoading(false);
      });
    return () => { active = false; };
  // Reload when stock changes (auto-refresh or a change on this device), so
  // the bell and sidebar badge stay equal to the Dashboard card.
  }, [notificationPreferenceKey, policyLoading, safetyStock, dataRevision, policyRefreshKey]);

  /* ===== RESTOCK REQUESTS IN THE BELL =====
     Staff "Notify" requests (Reorder Alerts). Checked every 30 seconds while
     the system is open, for accounts allowed to see them (Role Access). */
  const canSeeRequests = can('reorder.requests') && can('notifications.view');
  const [requestsVersion, setRequestsVersion] = useState(0);
  useEffect(() => {
    if (!canSeeRequests) {
      setNotifications((previous) => previous.filter((notification) => !notification.id.startsWith('request-')));
      return undefined;
    }
    let active = true;
    const loadRequests = async () => {
      try {
        const response = await fetch('/api/restock-requests', { headers: { Accept: 'application/json' }, cache: 'no-store' });
        if (!response.ok || !active) return;
        const requests = await response.json();
        if (!active || !Array.isArray(requests)) return;
        const items = requests.map((request) => ({
          id: `request-${request.id}`,
          type: 'warning',
          title: `Restock request: ${request.productName}`,
          meta: `${request.requestedBy}${request.note ? `: “${request.note}”` : ''} · ${request.stock ?? 0} on hand`,
          time: formatNotificationTime(request.createdAt),
          view: 'Reorder-Alerts',
          read: false,
          kind: 'request',
          product: request.productName,
          requestedBy: request.requestedBy,
          note: request.note,
          stock: request.stock ?? 0,
        }));
        // Forget read/cleared marks of requests that are closed now.
        const activeIds = new Set(items.map((item) => item.id));
        const previousPrefs = notificationPreferencesRef.current;
        const nextPrefs = {
          readIds: previousPrefs.readIds.filter((id) => !id.startsWith('request-') || activeIds.has(id)),
          dismissedIds: previousPrefs.dismissedIds.filter((id) => !id.startsWith('request-') || activeIds.has(id)),
        };
        if (nextPrefs.readIds.length !== previousPrefs.readIds.length || nextPrefs.dismissedIds.length !== previousPrefs.dismissedIds.length) {
          saveNotificationPreferences(nextPrefs);
        }
        const readIds = new Set(nextPrefs.readIds);
        const dismissedIds = new Set(nextPrefs.dismissedIds);
        setNotifications((previous) => [
          ...items.filter((item) => !dismissedIds.has(item.id)).map((item) => ({ ...item, read: readIds.has(item.id) })),
          ...previous.filter((notification) => !notification.id.startsWith('request-')),
        ]);
      } catch {
        /* offline for a moment — try again on the next tick */
      }
    };
    loadRequests();
    const timer = window.setInterval(loadRequests, 30000);
    return () => {
      active = false;
      window.clearInterval(timer);
    };
  }, [canSeeRequests, requestsVersion, notificationPreferenceKey]); // saveNotificationPreferences/ref are stable for this key

  /* ===== ACCOUNT REQUESTS IN THE BELL (Super Admin, 2026-11-03) =====
     "Request Account Access" from the login page. Checked every 30 seconds,
     and right away when the Staffs page approves or rejects one. Clicking
     opens Staffs, where the request is approved or rejected. */
  const canSeeAccountRequests = isSuperAdminRole && can('notifications.view');
  useEffect(() => {
    if (!canSeeAccountRequests) {
      setNotifications((previous) => previous.filter((notification) => !notification.id.startsWith('account-')));
      return undefined;
    }
    let active = true;
    const loadAccountRequests = async () => {
      try {
        const response = await fetch('/staff/account-requests', { headers: { Accept: 'application/json' }, cache: 'no-store' });
        if (!response.ok || !active) return;
        const requests = await response.json();
        if (!active || !Array.isArray(requests)) return;
        const items = requests.filter((request) => request.status === 'pending').map((request) => ({
          id: `account-${request.id}`,
          type: 'info',
          title: `Account request: ${request.name}`,
          meta: `${request.email} · ${request.department || 'No department'} · Approve & Invite in Staffs`,
          time: formatNotificationTime(request.createdAt),
          view: 'Staffs',
          read: false,
          kind: 'account',
        }));
        const prefs = notificationPreferencesRef.current;
        const readIds = new Set(prefs.readIds);
        const dismissedIds = new Set(prefs.dismissedIds);
        setNotifications((previous) => [
          ...items.filter((item) => !dismissedIds.has(item.id)).map((item) => ({ ...item, read: readIds.has(item.id) })),
          ...previous.filter((notification) => !notification.id.startsWith('account-')),
        ]);
      } catch {
        /* offline for a moment — try again on the next tick */
      }
    };
    loadAccountRequests();
    const timer = window.setInterval(loadAccountRequests, 30000);
    window.addEventListener('ggg-account-requests-changed', loadAccountRequests);
    return () => {
      active = false;
      window.clearInterval(timer);
      window.removeEventListener('ggg-account-requests-changed', loadAccountRequests);
    };
  }, [canSeeAccountRequests, notificationPreferenceKey]); // the preferences ref is stable for this key

  /* ===== AUTO-REFRESH =====
     Every 5 seconds while the browser tab is visible, ask the server for a
     tiny "data version" (a few bytes, see DataVersionController). When it
     changes — someone added, edited or deleted something on any computer —
     the open pages reload their data quietly. Nothing is reloaded when
     nothing changed. */
  useEffect(() => {
    let stopped = false;
    let busy = false;
    let knownVersion = null;
    const check = async () => {
      if (busy || document.visibilityState !== 'visible') return;
      busy = true;
      try {
        const response = await fetch('/api/data-version', { headers: { Accept: 'application/json' }, cache: 'no-store' });
        if (!response.ok) return;
        const { version } = await response.json();
        if (stopped || !version) return;
        if (knownVersion && knownVersion !== version) {
          setDataRevision((n) => n + 1);
          setPolicyRefreshKey((key) => key + 1);      // Stock Control, Reorder Alerts, calculator, Forecasting, Reports, bell
          setRequestsVersion((version) => version + 1); // restock requests in the bell
          refreshPermissions();                          // Role Access may have changed
        }
        knownVersion = version;
      } catch {
        /* offline for a moment — try again on the next tick */
      } finally {
        busy = false;
      }
    };
    check();
    const timer = window.setInterval(check, 5000);
    const onVisible = () => { if (document.visibilityState === 'visible') check(); };
    document.addEventListener('visibilitychange', onVisible);
    return () => {
      stopped = true;
      window.clearInterval(timer);
      document.removeEventListener('visibilitychange', onVisible);
    };
  }, []);

  useEffect(() => {
    let active = true;
    fetch('/api/safety-stock', { headers: { Accept: 'application/json' } })
      .then((response) => {
        if (!response.ok) throw new Error(`Could not load reorder policies (${response.status}).`);
        return response.json();
      })
      .then((records) => {
        if (!Array.isArray(records)) throw new Error('The reorder policy response was invalid.');
        if (active) {
          setSafetyStock(mapSafetyStockPolicies(records));
          setPolicyError('');
        }
      })
      .catch((error) => {
        if (active) setPolicyError(error.message || 'Could not load reorder policies.');
      })
      .finally(() => {
        if (active) setPolicyLoading(false);
      });
    return () => { active = false; };
  }, [policyRefreshKey]);

  const saveSafetyStock = async (draft) => {
    const policies = Object.entries(draft).map(([productId, values]) => ({
      productId,
      safetyStock: values.safetyStock,
      // Lead-time override only; blank = use the supplier's lead time.
      leadTimeDays: values.leadTimeDays === '' ? null : values.leadTimeDays,
      statusMode: values.statusMode === 'manual' ? 'manual' : 'auto',
      lowPoint: values.statusMode === 'manual' ? values.lowPoint : null,
      criticalPoint: values.statusMode === 'manual' ? values.criticalPoint : null,
    }));
    const response = await apiFetch('/api/safety-stock', {
      method: 'PUT',
      headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
      body: JSON.stringify({ policies }),
    });
    if (!response.ok) {
      const body = await response.json().catch(() => null);
      const validationMessage = Object.values(body?.errors || {}).flat()[0];
      throw new Error(validationMessage || body?.message || `Could not apply reorder policy (${response.status}).`);
    }
    const records = await response.json();
    setSafetyStock(mapSafetyStockPolicies(records));
    setPolicyError('');
  };

  /* ===== OUTSIDE CLICK ===== */
  useEffect(() => {
    if (!isNotifOpen) return;
    const handleClickOutside = (e) => {
      if (notifRef.current && !notifRef.current.contains(e.target)) {
        setIsNotifOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isNotifOpen]);

  const markAllRead = () => {
    const readIds = new Set(notificationPreferencesRef.current.readIds);
    notifications.forEach((notification) => readIds.add(notification.id));
    saveNotificationPreferences({
      ...notificationPreferencesRef.current,
      readIds: [...readIds],
    });
    setNotifications((previous) => previous.map((notification) => ({ ...notification, read: true })));
  };
  const clearNotifications = () => {
    const dismissedIds = new Set(notificationPreferencesRef.current.dismissedIds);
    notifications.forEach((notification) => dismissedIds.add(notification.id));
    saveNotificationPreferences({
      ...notificationPreferencesRef.current,
      dismissedIds: [...dismissedIds],
    });
    setNotifications([]);
  };

  /* ===== OPEN NOTIFICATION ===== */
  const openNotification = (notif) => {
    const readIds = new Set(notificationPreferencesRef.current.readIds);
    readIds.add(notif.id);
    saveNotificationPreferences({
      ...notificationPreferencesRef.current,
      readIds: [...readIds],
    });
    setNotifications((prev) => prev.map((n) => (n.id === notif.id ? { ...n, read: true } : n)));
    if (notif.view) {
      handleNavigate(notif.view);
      setIsNotifOpen(false);
    }
  };

  const handleLogout = async () => {
    if (logoutProcessingRef.current) return;
    logoutProcessingRef.current = true;
    setIsLoggingOut(true);
    try {
      await onLogout?.();
      setIsLogoutConfirmOpen(false);
    } finally {
      logoutProcessingRef.current = false;
      setIsLoggingOut(false);
    }
  };

  /* ===== NAVIGATION ===== */
  const handleNavigate = (requestedView, payload = null) => {
    // The calculator now lives inside Forecasting (Economic Order Quantity
    // tab). "Order Now" and the Stock Control shortcut still ask for
    // 'Auto-Calculator': open Forecasting with that product instead.
    const view = requestedView === 'Auto-Calculator' ? 'Forecasting' : requestedView;
    if (requestedView === 'Auto-Calculator' && !canAccess('Auto-Calculator')) return;
    if (!canAccess(view)) return; // role not permitted — ignore
    if (mainContentRef.current) {
      viewScrollPositions.current[activeView] = mainContentRef.current.scrollTop;
    }
    setVisitedViews((previous) => {
      if (previous.has(view)) return previous;
      return new Set(previous).add(view);
    });
    if (payload) {
      setHandoff(payload);
      if (payload.type === 'forecast-eoq' && user?.id) {
        try {
          window.sessionStorage.setItem(eoqHandoffStorageKey(user.id), JSON.stringify(payload));
        } catch (storageError) {
          console.error('Could not persist the forecast EOQ handoff:', storageError);
        }
      }
    } else {
      setHandoff(null);
    }
    setActiveView(view);
    setIsSidebarOpen(false);
  };

  const clearEoqHandoff = useCallback(() => {
    setHandoff(null);
    if (!user?.id) return;
    try {
      window.sessionStorage.removeItem(eoqHandoffStorageKey(user.id));
    } catch (storageError) {
      console.error('Could not clear the forecast EOQ handoff:', storageError);
    }
  }, [user?.id]);

  useLayoutEffect(() => {
    const mainContent = mainContentRef.current;
    if (!mainContent) return;
    mainContent.scrollTop = viewScrollPositions.current[activeView] ?? 0;
  }, [activeView]);
  return (

    <div className="dashboard-page-wrapper"> {/* ===== PAGE WRAPPER ===== */}
      <div className="dashboard-container-parent">
        {/* ===== SIDEBAR BACKDROP ===== */}
        {isSidebarOpen && (
          <div className="sidebar-backdrop" onClick={() => setIsSidebarOpen(false)} aria-hidden="true" />
        )}
        <aside className={`sidebar-body ${isSidebarOpen ? 'open' : ''}${sidebarExpanded ? ' is-expanded' : ''}`}>
{/* ===== SIDEBAR NAVIGATION ===== */}
  <ul className="sidebar-menu">
      <div className="sidebar-item sidebar-logo-row">
{/* ===== LOGO (profile icon, or the Super Admin's chosen picture) ===== */}
        {isSuperAdminUser ? (
          <button
            id="sidebar-logo"
            type="button"
            className="sidebar-logo-editable"
            onClick={() => setIsLogoModalOpen(true)}
            title="Change system logo"
            aria-label="Change system logo"
          >
            {logoContent}
            <span className="sidebar-logo-camera" aria-hidden="true"><Camera size={9} /></span>
          </button>
        ) : (
          <span id="sidebar-logo" aria-hidden="true">{logoContent}</span>
        )}
        <span className="sidebar-brand">
          <strong>GGG Inventory</strong>
          <small>Inventory Management</small>
        </span>
        {/* ===== ICONS ONLY / ICONS WITH NAMES (desktop) ===== */}
        <button
          type="button"
          className="sidebar-mode-toggle"
          onClick={toggleSidebarMode}
          aria-pressed={sidebarExpanded}
          aria-label={sidebarExpanded ? 'Show icons only' : 'Show icons with names'}
          title={sidebarExpanded ? 'Show icons only' : 'Show icons with names'}
        >
          <PanelLeft size={16} strokeWidth={1.9} aria-hidden="true" />
        </button>
        {/* ===== CLOSE BUTTON ===== */}
        <button
          className="sidebar-close-btn"
          aria-label="Close menu"
          onClick={() => setIsSidebarOpen(false)}
        >
          <X size={18} />
        </button>
      </div>



{/* ===== MENUS ===== */}
          <li className="sidebar-section-label">Overview</li>
          <li className={`sidebar-item ${activeView === 'Dashboard' ? 'active' : ''}`}>
            <button onClick={() => handleNavigate('Dashboard')}>
              <LayoutDashboard className="sidebar-icon" />
              <span className="sidebar-label">Dashboard</span>
            </button>
          </li>
          {(canAccess('Product-Supplier') || canAccess('Stock') || canAccess('Reorder-Alerts')) && <li className="sidebar-section-label">Inventory</li>}
          {canAccess('Product-Supplier') && (
          <li className={`sidebar-item ${activeView === 'Product-Supplier' ? 'active' : ''}`}>
            <button onClick={() => handleNavigate('Product-Supplier')}>
              <Users className="sidebar-icon" />
              <span className="sidebar-label"> Management </span>
            </button>
          </li>
          )}
          {canAccess('Stock') && (
          <li className={`sidebar-item ${activeView === 'Stock' ? 'active' : ''}`}>
            <button onClick={() => handleNavigate('Stock')}>
              <Boxes className="sidebar-icon" />
              <span className="sidebar-label">Stock Control</span>
            </button>
          </li>
          )}
          {canAccess('Reorder-Alerts') && (
          <li className={`sidebar-item ${activeView === 'Reorder-Alerts' ? 'active' : ''}`}>
            <button onClick={() => handleNavigate('Reorder-Alerts')} title={reorderAlertCount ? `${reorderAlertCount} items need reorder` : 'Reorder List'}>
              <BellRing className="sidebar-icon" />
              <span className="sidebar-label">Reorder List</span>
              {reorderAlertCount > 0 && (
                <span className="sidebar-count-badge" aria-label={`${reorderAlertCount} items need reorder`}>
                  {reorderAlertCount > 99 ? '99+' : reorderAlertCount}
                </span>
              )}
            </button>
          </li>
          )}
          {canAccess('Forecasting') && <li className="sidebar-section-label">Planning</li>}
          {canAccess('Forecasting') && (
          <li className={`sidebar-item ${activeView === 'Forecasting' ? 'active' : ''}`}>
            <button onClick={() => handleNavigate('Forecasting')}>
              <TrendingUp className="sidebar-icon" />
              <span className="sidebar-label">Forecasting</span>
            </button>
          </li>
          )}
          {/* Economic Order Quantity Calculator: now a tab inside Forecasting. */}
          {canAccess('Reports') && <li className="sidebar-section-label">Analytics</li>}
          {canAccess('Reports') && (
          <li className={`sidebar-item ${activeView === 'Reports' ? 'active' : ''}`}>
            <button onClick={() => handleNavigate('Reports')}>
              <BarChart3 className="sidebar-icon" />
              <span className="sidebar-label">Reports</span>
            </button>
          </li>
          )}
        </ul>


 {/* ===== FOOTER ===== */}
        <div className="sidebar-footer-item">
            <div className = "sub-sidebar-footer-item">

              {canAccess('Staffs') && (
              <div className={`siderbar-item ${activeView === 'Staffs' ? 'active' : ''}`}>
                <button onClick={() => handleNavigate('Staffs')} title="Staff-list">
                  <UsersRound className="sidebar-icon"/>
                  <span className="sidebar-label">Staffs</span>
                </button>
              </div>
              )}
              {canAccess('Trash-Archive') && (
              <div className={`siderbar-item ${activeView === 'Trash-Archive' ? 'active' : ''}`}>
                <button onClick={() => handleNavigate('Trash-Archive')} title="Trash Bin and Archive">
                  <Trash2 className="sidebar-icon"/>
                  <span className="sidebar-label">Trash &amp; Archive</span>
                </button>
              </div>
              )}
              <div className={`siderbar-item ${activeView === 'Profile' ? 'active' : ''}`}>
                <button onClick={() => handleNavigate('Profile')} title="User Profile">
                  <User className="sidebar-icon"/>
                  <span className="sidebar-label">Profile</span>
                </button>
              </div>
              <div className={`siderbar-item ${activeView === 'Setting' ? 'active' : ''}`}>
                <button onClick={() => handleNavigate('Setting')}>
                  <SettingsIcon className="sidebar-icon"/>
                  <span className="sidebar-label">Setting</span>
                </button>
              </div>
            </div>

            <div className = "sub-sidebar-footer-item-logout">
              {/* Signed-in person (open sidebar only); opens Profile. */}
              <button type="button" className="sidebar-user" onClick={() => handleNavigate('Profile')} title="Open your profile">
                <span className={`sidebar-user-avatar${avatarUrl ? ' has-photo' : ''}`} aria-hidden="true">
                  {avatarUrl ? <img src={avatarUrl} alt="" /> : String(user?.name || '?').trim().split(/\s+/).filter(Boolean).slice(0, 2).map((part) => part[0]).join('').toUpperCase() || '?'}
                </span>
                <span className="sidebar-user-text">
                  <strong>{user?.name || 'Account'}</strong>
                  <small>{roleLabel}</small>
                </span>
              </button>
              <div id="log-out" className="sidebar-item">
                <button onClick={() => setIsLogoutConfirmOpen(true)} aria-label="Logout" title="Logout">
                  <LogOut className="sidebar-icon" />
                  <span className="sidebar-label">Logout</span>
                </button>
              </div>
            </div>
        </div>
      </aside>




{/* ===== MAIN WRAPPER ===== */}
        <div className="main-wrapper">
          <header className="top-navbar">
            <div className="top-navbar-left-side">
              {/* ===== MENU BUTTON ===== */}
              <button
                className="navbar-menu-toggle"
                aria-label="Open menu"
                aria-expanded={isSidebarOpen}
                onClick={() => setIsSidebarOpen((open) => !open)}
              >
                <Menu size={18} />
              </button>

              <div className="page-title-row">
                <p>
                  {activeView === 'Dashboard' && 'Dashboard Overview'}
                  {activeView === 'Product-Supplier' && 'Product & Supplier'}
                  {activeView === 'Stock' && 'Stock Control'}
                  {activeView === 'Reorder-Alerts' && 'Reorder List'}
                  {activeView === 'Auto-Calculator' && 'Economic Order Quantity Calculator'}
                  {activeView === 'Forecasting' && 'Sales Forecasting'}
                  {activeView === 'Reports' && 'Reports & Analytics'}

                  {activeView === 'Staffs' && 'Staffs'}
                  {activeView === 'Trash-Archive' && 'Trash Bin & Archive'}
                  {activeView === 'Setting' && 'Settings'}
                  {activeView === 'Profile' && 'User Profile'}
                </p>

                <p className= "sub-title">
                  {activeView === 'Dashboard' && 'Detailed Information about your store'}
                  {activeView === 'Product-Supplier' && 'Item specifications and supplier information'}
                  {activeView === 'Stock' && 'Product details and assigned supplier tracking'}
                  {activeView === 'Reorder-Alerts' && 'Products that have reached their reorder point'}
                  {activeView === 'Auto-Calculator' && 'Optimize product order sizes and minimize supplier carrying costs'}
                  {activeView === 'Forecasting' && 'Analyze historical trends to project future inventory demand'}
                  {activeView === 'Reports' && 'Review inventory performance, optimization metrics, and forecasting trends'}

                  {activeView === 'Staffs' && 'Manage staffs'}
                  {activeView === 'Trash-Archive' && 'Restore, archive, or permanently delete records'}
                  {activeView === 'Setting' && 'Manage your workspace preferences'}
                  {activeView === 'Profile' && 'View and manage your accounts details'}
                </p>
              </div>
            </div>

            {/* ===== NOTIFICATION BUTTON ===== */}
            <div className = "top-navbar-right-side">
              {can('notifications.view') && (
              <div className="notif-wrapper" ref={notifRef}>
                <button
                  className="navbar-bell-icon"
                  aria-label="Notifications"
                  aria-expanded={isNotifOpen}
                  onClick={() => setIsNotifOpen((open) => !open)}
                >
                  <Bell size={16} />
                  {bellCount > 0 && (
                    <span className="notif-bell-badge">{bellCount > 9 ? '9+' : bellCount}</span>
                  )}
                </button>

                {isNotifOpen && (
                  <div className="notif-box" role="menu">
                    <div className="notif-box-header">
                      <div className="notif-box-title">
                        <span>Notifications</span>
                        {unreadCount > 0 && <span className="notif-box-count">{unreadCount} new</span>}
                      </div>
                      {notifications.length > 0 && (
                        <button
                          className="notif-box-action"
                          type="button"
                          onClick={markAllRead}
                          disabled={unreadCount === 0}
                        >
                          <Check size={12} /> Mark all read
                        </button>
                      )}
                    </div>

                    {notifications.length > 0 && (() => {
                      const counts = notifications.reduce((total, n) => {
                        const key = n.kind === 'request' || n.kind === 'account' ? n.kind : n.level === 'low' ? 'low' : 'out';
                        total[key] = (total[key] || 0) + 1;
                        return total;
                      }, {});
                      return (
                        <div className="notif-summary" aria-label="Summary">
                          {counts.out > 0 && <span className="notif-chip is-out"><i />{counts.out} Out / critical</span>}
                          {counts.low > 0 && <span className="notif-chip is-low"><i />{counts.low} Low</span>}
                          {counts.request > 0 && <span className="notif-chip is-request"><i />{counts.request} Request{counts.request === 1 ? '' : 's'}</span>}
                          {counts.account > 0 && <span className="notif-chip is-request"><i />{counts.account} Account request{counts.account === 1 ? '' : 's'}</span>}
                        </div>
                      );
                    })()}

                    <div className="notif-box-list">
                      {notificationsLoading ? (
                        <div className="notif-empty" role="status">Loading notifications…</div>
                      ) : notificationError ? (
                        <div className="notif-empty" role="alert">{notificationError}</div>
                      ) : notifications.length === 0 ? (
                        <div className="notif-empty">
                          <span className="notif-empty-icon"><BellOff size={20} /></span>
                          <strong>You’re all caught up</strong>
                          <span>Stock alerts and restock requests show here.</span>
                        </div>
                      ) : (
                        notifications.map((notif) => {
                          const { Icon, cls } = NOTIF_ICONS[notif.type] || NOTIF_ICONS.info;
                          if (notif.kind === 'stock' || notif.kind === 'request') {
                            const isRequest = notif.kind === 'request';
                            const level = isRequest ? 'request' : notif.level;
                            const fill = !isRequest && notif.reorderPoint > 0
                              ? Math.min(100, (notif.stock / notif.reorderPoint) * 100)
                              : 0;
                            return (
                              <button
                                key={notif.id}
                                type="button"
                                className={`notif-item notif-row is-${level} ${notif.read ? '' : 'is-unread'}`}
                                onClick={() => openNotification(notif)}
                                title={notif.meta}
                              >
                                <span className={`notif-item-icon ${isRequest ? 'notif-ic-request' : cls}`}>
                                  {isRequest ? <BellRing size={15} /> : <Icon size={15} />}
                                </span>
                                <span className="notif-item-body">
                                  <span className="notif-row-top">
                                    <span className="notif-row-name">{notif.product}</span>
                                    <span className={`notif-pill is-${level}`}>
                                      {isRequest ? 'Request' : { out: 'Out of stock', critical: 'Critical', low: 'Low' }[level]}
                                    </span>
                                  </span>
                                  {isRequest ? (
                                    <span className="notif-row-sub">
                                      {notif.requestedBy}{notif.note ? ` · “${notif.note}”` : ''} · {notif.stock} on hand
                                    </span>
                                  ) : (
                                    <span className="notif-stock" aria-label={`${notif.stock} on hand, reorder point ${notif.reorderPoint}`}>
                                      <span className="notif-stock-track"><span className="notif-stock-fill" style={{ width: `${fill}%` }} /></span>
                                      <span className="notif-stock-text"><strong>{notif.stock}</strong> / {notif.reorderPoint}</span>
                                    </span>
                                  )}
                                  {isRequest && <span className="notif-item-time">{notif.time}</span>}
                                </span>
                                {!notif.read && <span className="notif-item-dot" aria-hidden="true" />}
                              </button>
                            );
                          }
                          return (
                            <button
                              key={notif.id}
                              type="button"
                              className={`notif-item ${notif.read ? '' : 'is-unread'}`}
                              onClick={() => openNotification(notif)}
                            >
                              <span className={`notif-item-icon ${cls}`}><Icon size={15} /></span>
                              <span className="notif-item-body">
                                <span className="notif-item-title">{notif.title}</span>
                                <span className="notif-item-meta">{notif.meta}</span>
                                <span className="notif-item-time">{notif.time}</span>
                              </span>
                              {!notif.read && <span className="notif-item-dot" aria-hidden="true" />}
                            </button>
                          );
                        })
                      )}
                    </div>

                    {notifications.length > 0 && (
                      <div className="notif-box-footer">
                        <button className="notif-box-clear" type="button" onClick={clearNotifications}>
                          Clear all
                        </button>
                        <button
                          className="notif-box-open"
                          type="button"
                          onClick={() => { setIsNotifOpen(false); handleNavigate('Reorder-Alerts'); }}
                        >
                          Open Reorder List →
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
              )}
            </div>
          </header>
            <main
              ref={mainContentRef}
              className={`main-content-window ${activeView === 'Auto-Calculator' ? 'no-fade' : ''}`}
            >
              {/* ===== CONTENT VIEWS (each also guarded by role) ===== */}
              {visitedViews.has('Dashboard') && canAccess('Dashboard') && (
                <div className="app-view-panel" hidden={activeView !== 'Dashboard'}>
                  <Dashboard
                    onNavigate={handleNavigate}
                    canOpen={canAccess}
                    fetchSummary={fetchDashboardSummary}
                    dataRevision={dataRevision}
                    isSuperAdmin={role === 'super_admin'}
                    safetyStock={safetyStock}
                    isActive={activeView === 'Dashboard'}
                  />
                </div>
              )}
              {visitedViews.has('Product-Supplier') && canAccess('Product-Supplier') && (
                <div className="app-view-panel" hidden={activeView !== 'Product-Supplier'}>
                  <ProductSupplier
                    handoff={handoff}
                    dataRevision={dataRevision}
                    onCatalogChange={() => setPolicyRefreshKey((key) => key + 1)}
                    canAddProduct={can('products.create')}
                    canEditProduct={can('products.edit')}
                    canDeleteProduct={can('products.delete')}
                    canExportProducts={can('products.export')}
                    canViewSuppliers={can('suppliers.view')}
                    canManageSuppliers={can('suppliers.manage')}
                  />
                </div>
              )}
              {visitedViews.has('Stock') && canAccess('Stock') && (
                <div className="app-view-panel" hidden={activeView !== 'Stock'}>
                  <StockManagement
                    onNavigate={handleNavigate}
                    safetyStock={safetyStock}
                    handoff={handoff}
                    catalogRevision={policyRefreshKey}
                    onInventoryChanged={() => setPolicyRefreshKey((key) => key + 1)}
                    currentUserName={user?.name || ''}
                    canComputeEoq={canAccess('Auto-Calculator') && canAccess('Forecasting')}
                    canClearStock={can('stock.clear')}
                    canAddStock={can('stock.create')}
                    canEditStock={can('stock.edit')}
                    canDeleteStock={can('stock.delete')}
                    canExportStock={can('stock.export')}
                    canViewActivity={can('stock.history')}
                  />
                </div>
              )}
              {visitedViews.has('Reorder-Alerts') && canAccess('Reorder-Alerts') && (
                <div className="app-view-panel reorder-alerts-panel" hidden={activeView !== 'Reorder-Alerts'}>
                  <ReorderAlerts
                    onNavigate={handleNavigate}
                    safetyStock={safetyStock}
                    catalogRevision={policyRefreshKey}
                    canComputeEoq={canAccess('Auto-Calculator')}
                    canNotify={can('reorder.notify')}
                    canManageRequests={can('reorder.requests')}
                    canReceive={can('reorder.receive')}
                    onRequestsChanged={() => setRequestsVersion((version) => version + 1)}
                    onStockChanged={() => setPolicyRefreshKey((key) => key + 1)}
                  />
                </div>
              )}
              {visitedViews.has('Forecasting') && canAccess('Forecasting') && (
                <div className="app-view-panel" hidden={activeView !== 'Forecasting'}>
                  <SalesForecasting
                    onNavigate={handleNavigate}
                    onClearEoqHandoff={clearEoqHandoff}
                    catalogRevision={policyRefreshKey}
                    isActive={activeView === 'Forecasting'}
                    canExport={can('forecast.export')}
                    canEditPastSales={can('forecast.past_sales')}
                    canManageEvents={can('forecast.events')}
                    canComputeEoq={canAccess('Auto-Calculator')}
                    handoff={activeView === 'Forecasting' ? handoff : null}
                    currentUser={user?.name || ''}
                    currentUserId={user?.id || ''}
                    safetyStock={safetyStock}
                    canSaveEoqCosts={can('calculator.save_costs')}
                    canViewEoqHistory={can('calculator.history')}
                    canExportEoq={can('calculator.export')}
                  />
                </div>
              )}
              {visitedViews.has('Staffs') && canAccess('Staffs') && (
                <div className="app-view-panel" hidden={activeView !== 'Staffs'}>
                  <Staffs isSuperAdmin={user?.isSuperAdmin === true} canManageStaff={role === 'admin' && can('staff.manage')} onSessionRevoked={onSessionRevoked} />
                </div>
              )}
              {visitedViews.has('Reports') && canAccess('Reports') && (
                <div className="app-view-panel" hidden={activeView !== 'Reports'}>
                  <ReportAnalytics
                    safetyStock={safetyStock}
                    refreshKey={`${policyRefreshKey}-${dataRevision}`}
                    isActive={activeView === 'Reports'}
                    canTab={(key) => can(`reports.tab.${key}`)}
                    canExport={can('reports.export')}
                  />
                </div>
              )}
              {visitedViews.has('Trash-Archive') && canAccess('Trash-Archive') && (
                <div className="app-view-panel" hidden={activeView !== 'Trash-Archive'}>
                  <TrashBin
                    isActive={activeView === 'Trash-Archive'}
                    refreshKey={`${policyRefreshKey}-${dataRevision}`}
                    onRestored={() => setPolicyRefreshKey((key) => key + 1)}
                  />
                </div>
              )}
              {visitedViews.has('Setting') && canAccess('Setting') && (
                <div className="app-view-panel" hidden={activeView !== 'Setting'}>
                  <Settings
                    theme={theme}
                    onThemeChange={onThemeChange}
                    role={roleLabel}
                    safetyStock={safetyStock}
                    onUpdateSafetyStock={saveSafetyStock}
                    policyLoading={policyLoading}
                    policyError={policyError}
                    canChangeCurrency={can('settings.currency')}
                    isSuperAdmin={isSuperAdminRole}
                  />
                </div>
              )}
              {visitedViews.has('Profile') && canAccess('Profile') && (
                <div className="app-view-panel" hidden={activeView !== 'Profile'}>
                  <Profile />
                </div>
              )}
            </main>
        </div>
      </div>
      {isLogoModalOpen && isSuperAdminUser && createPortal(
        <div className="logout-confirm-overlay" onClick={closeLogoModal}>
          <section
            className="logout-confirm-modal logo-picker-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="logo-picker-title"
            onClick={(event) => event.stopPropagation()}
          >
            <span className={`logo-picker-preview${logoDraft ? ' is-checker' : ''}`} aria-hidden="true">
              {logoDraft
                ? <img src={logoRemoveBg && logoCleaned ? logoCleaned.url : logoDraft.url} alt="" />
                : logoUrl ? <img src={logoUrl} alt="" /> : <CircleUserRound size={40} />}
            </span>
            <h2 id="logo-picker-title">{logoDraft ? 'Preview your logo' : 'System logo'}</h2>
            {logoDraft ? (
              <>
                <p className="hint-text">The checkered squares show the see-through parts. If the logo sits on one plain colour (like white), turn on the switch to remove it.</p>
                <label className="logo-bg-switch">
                  <input type="checkbox" checked={logoRemoveBg} onChange={(event) => setLogoRemoveBg(event.target.checked)} disabled={logoBusy} />
                  <span>Remove plain background</span>
                </label>
                {logoRemoveBg && (
                  <label className="logo-bg-strength">
                    <span>Strength</span>
                    <input
                      type="range"
                      min="10"
                      max="120"
                      step="5"
                      value={logoBgStrength}
                      onChange={(event) => setLogoBgStrength(Number(event.target.value))}
                      disabled={logoBusy}
                      aria-label="How much of the background colour to remove"
                    />
                  </label>
                )}
                {logoRemoveBg && (
                  <p className="logo-bg-note" role="status">
                    {logoCleaning
                      ? 'Removing the background…'
                      : logoCleaned?.alreadyClear
                        ? 'This picture already has a see-through background.'
                        : logoCleaned
                          ? `${Math.round(logoCleaned.removed * 100)}% of the picture is now see-through. Move Strength if too much or too little was removed.`
                          : ''}
                  </p>
                )}
              </>
            ) : (
              <p>The system’s logo at the top of the sidebar, shown to every account. JPG, PNG, WEBP or GIF, up to 2 MB.</p>
            )}
            {logoError && <p className="logo-picker-error" role="alert">{logoError}</p>}
            <input
              ref={logoFileRef}
              type="file"
              accept="image/png,image/jpeg,image/webp,image/gif"
              onChange={pickLogo}
              hidden
            />
            {logoDraft ? (
              <div className="logout-confirm-actions">
                <button type="button" className="logout-confirm-cancel" onClick={clearLogoDraft} disabled={logoBusy}>
                  Back
                </button>
                <button type="button" className="logout-confirm-cancel" onClick={() => logoFileRef.current?.click()} disabled={logoBusy}>
                  Other picture
                </button>
                <button
                  type="button"
                  className="logout-confirm-submit logo-picker-choose"
                  onClick={uploadLogo}
                  disabled={logoBusy || (logoRemoveBg && logoCleaning)}
                >
                  {logoBusy ? 'Saving…' : 'Save logo'}
                </button>
              </div>
            ) : (
            <div className="logout-confirm-actions">
              {logoUrl && (
                <button type="button" className="logout-confirm-cancel" onClick={removeLogo} disabled={logoBusy}>
                  <Trash2 size={13} /> Remove
                </button>
              )}
              <button type="button" className="logout-confirm-cancel" onClick={closeLogoModal} disabled={logoBusy}>
                Cancel
              </button>
              <button
                type="button"
                className="logout-confirm-submit logo-picker-choose"
                onClick={() => logoFileRef.current?.click()}
                disabled={logoBusy}
              >
                {logoBusy ? 'Saving…' : logoUrl ? 'Change logo' : 'Choose logo'}
              </button>
            </div>
            )}
          </section>
        </div>,
        document.body
      )}

      {isLogoutConfirmOpen && createPortal(
        <div
          className="logout-confirm-overlay"
          onClick={() => {
            if (!logoutProcessingRef.current) setIsLogoutConfirmOpen(false);
          }}
        >
          <section
            className="logout-confirm-modal"
            role="alertdialog"
            aria-modal="true"
            aria-labelledby="logout-confirm-title"
            aria-describedby="logout-confirm-description"
            onClick={(event) => event.stopPropagation()}
          >
            <span className="logout-confirm-icon" aria-hidden="true"><LogOut size={20} /></span>
            <h2 id="logout-confirm-title">Are you sure you want to log out?</h2>
            <p id="logout-confirm-description">You will need to log in again to access your account.</p>
            <div className="logout-confirm-actions">
              <button
                ref={logoutCancelRef}
                type="button"
                className="logout-confirm-cancel"
                onClick={() => setIsLogoutConfirmOpen(false)}
                disabled={isLoggingOut}
              >
                Cancel
              </button>
              <button
                type="button"
                className="logout-confirm-submit"
                onClick={handleLogout}
                disabled={isLoggingOut}
              >
                {isLoggingOut ? 'Logging Out…' : 'Yes, Log Out'}
              </button>
            </div>
          </section>
        </div>,
        document.body
      )}
    </div>
  );
}

export default LandingPage;

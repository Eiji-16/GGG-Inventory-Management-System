<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\ActivityLog;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Rules\Password;
use Illuminate\Validation\ValidationException;

/**
 * StaffController — /staff
 *
 * Backs the Staffs tab. The Super Admin can do everything. An Admin can use
 * it only when Role Access → "Manage Staff" is on, and then only for STAFF
 * accounts (create Staff, deactivate / reactivate / delete Staff, photos) —
 * never Admins or Super Admins and never role changes. Enforced here, not
 * just in the UI. Guards the last active Super Admin from being demoted,
 * deactivated, or deleted so the system can never lock everyone out.
 */
class StaffController extends Controller
{
    /** GET /staff?status=active|inactive (defaults to active accounts). */
    public function index(Request $request): JsonResponse
    {
        $this->authorizeManager($request);

        $filters = $request->validate([
            'status' => ['sometimes', Rule::in([User::STATUS_ACTIVE, User::STATUS_INACTIVE])],
        ]);
        $lastActivity = $this->lastActivityByUser();

        $users = User::where('status', $filters['status'] ?? User::STATUS_ACTIVE)
            ->orderBy('name')
            ->get();

        return response()->json($users->map(fn (User $u) => $this->format($u, $lastActivity)));
    }

    /** POST /staff — create an account with a chosen role. */
    public function store(Request $request): JsonResponse
    {
        $this->authorizeManager($request);

        $data = $request->validate([
            'name'                  => ['required', 'string', 'max:255'],
            'email'                 => ['required', 'email', 'max:255', 'unique:users,email'],
            'password'              => ['required', 'confirmed', Password::min(8)],
            'role'                  => ['required', Rule::in(User::ROLES)],
        ]);

        // An Admin may only create Staff accounts.
        abort_unless($this->isSuperAdminActor($request) || $data['role'] === User::ROLE_STAFF, 403, 'Admins can only create Staff accounts.');

        $user = User::create([
            'name'     => $data['name'],
            'email'    => $data['email'],
            'password' => $data['password'],
            'role'     => $data['role'],
            'status'   => User::STATUS_ACTIVE,
        ]);

        \App\Models\ActivityLog::record('staff.create', "Created account — {$user->name} ({$user->role})", 'user', ['email' => $user->email]);

        return response()->json($this->format($user, []), 201);
    }

    /** PATCH /staff/{user} — change role and/or status. */
    public function update(Request $request, User $user): JsonResponse
    {
        $this->authorizeManager($request, $user);

        $data = $request->validate([
            'role'   => ['sometimes', Rule::in(User::ROLES)],
            'status' => ['sometimes', Rule::in([User::STATUS_ACTIVE, User::STATUS_INACTIVE])],
        ]);
        // Changing roles stays with the Super Admin.
        abort_if(array_key_exists('role', $data) && ! $this->isSuperAdminActor($request), 403, 'Only the Super Admin can change roles.');

        $deactivated = DB::transaction(function () use ($data, $user): bool {
            $account = User::whereKey($user->id)->lockForUpdate()->firstOrFail();

            // Protect the last active Super Admin from losing that status.
            if (array_key_exists('role', $data) && $account->isSuperAdmin() && $data['role'] !== User::ROLE_SUPER_ADMIN) {
                $this->ensureNotLastSuperAdmin($account, 'demote');
            }
            if (array_key_exists('status', $data) && $account->isSuperAdmin() && $data['status'] === User::STATUS_INACTIVE) {
                $this->ensureNotLastSuperAdmin($account, 'deactivate');
            }

            $isDeactivation = $account->status === User::STATUS_ACTIVE
                && ($data['status'] ?? User::STATUS_ACTIVE) === User::STATUS_INACTIVE;
            $account->fill($data);
            if ($isDeactivation) {
                $account->auth_version = (int) $account->auth_version + 1;
            }
            $account->save();
            if ($isDeactivation) {
                $this->revokeDatabaseSessions($account);
            }

            return $isDeactivation;
        });

        return response()->json($this->format($user->fresh(), $this->lastActivityByUser()) + [
            'sessionRevoked' => $deactivated && $user->id === $request->user()->id,
        ]);
    }

    /** DELETE /api/staff/{user} */
    public function destroy(Request $request, User $user): JsonResponse
    {
        $this->authorizeManager($request, $user);

        if ($user->id === $request->user()->id) {
            throw ValidationException::withMessages([
                'user' => 'You cannot delete your own account.',
            ]);
        }

        $request->validate([
            'confirmation' => ['required', 'string', Rule::in(['DELETE'])],
        ]);

        DB::transaction(function () use ($request, $user): void {
            $account = User::whereKey($user->id)->lockForUpdate()->firstOrFail();

            if ($account->id === $request->user()->id) {
                throw ValidationException::withMessages([
                    'user' => 'You cannot delete your own account.',
                ]);
            }
            if ($account->status !== User::STATUS_INACTIVE) {
                throw ValidationException::withMessages([
                    'user' => 'Only deactivated accounts can be moved to the Trash Bin.',
                ]);
            }

            if ($account->isSuperAdmin()) {
                $this->ensureNotLastSuperAdmin($account, 'delete');
            }

            $this->revokeDatabaseSessions($account);

            DB::table('password_reset_tokens')->where('email', $account->email)->delete();
            DB::table('password_reset_otps')->where('email', $account->email)->delete();
            $account->auth_version = (int) $account->auth_version + 1;

            ActivityLog::create([
                'user_id' => $request->user()->id,
                'action' => 'staff.trash',
                'description' => "Moved account {$account->name} to the Trash Bin.",
                'icon' => 'user',
                'meta' => [
                    'deleted_user_id' => $account->id,
                    'deleted_user_email' => $account->email,
                    'deleted_user_role' => $account->role,
                ],
            ]);

            $account->forceFill([
                'deleted_by' => $request->user()->id,
                'deleted_by_name' => $request->user()->name ?: $request->user()->email,
            ])->save();
            $account->delete();
        });

        return response()->json(['trashed' => true]);
    }

    private function revokeDatabaseSessions(User $account): void
    {
        if (config('session.driver') !== 'database') {
            return;
        }

        DB::table(config('session.table', 'sessions'))
            ->where('user_id', $account->id)
            ->delete();
    }

    /*
     * ===== STAFF PROFILE PHOTO (Manage Staff) =====
     * The Super Admin can add, change or remove any account's photo. It is the
     * SAME photo the person sets in their own Profile ("avatar.user.{id}"), so
     * it shows in Staffs, their Profile and their sidebar. No photo = initials.
     */

    /** GET /staff/{user}/avatar */
    public function avatar(Request $request, User $user)
    {
        $this->authorizeManager($request, $user);
        $path = $user->avatarPath();
        abort_unless($path && \Illuminate\Support\Facades\Storage::disk('local')->exists($path), 404);

        return \Illuminate\Support\Facades\Storage::disk('local')->response($path, null, [
            'Cache-Control' => 'private, max-age=31536000',
            'X-Content-Type-Options' => 'nosniff',
        ]);
    }

    /** POST /staff/{user}/avatar — new or changed photo (field "avatar"). */
    public function storeAvatar(Request $request, User $user): JsonResponse
    {
        $this->authorizeManager($request, $user);
        $request->validate([
            'avatar' => ['required', 'image', 'mimes:jpg,jpeg,png,webp,gif', 'max:2048'],
        ], [
            'avatar.max' => 'The picture must be 2 MB or smaller.',
            'avatar.image' => 'Please choose an image file (JPG, PNG, WEBP or GIF).',
            'avatar.mimes' => 'Please choose a JPG, PNG, WEBP or GIF picture.',
        ]);

        $old = $user->avatarPath();
        $path = $request->file('avatar')->store('avatars', 'local');
        \App\Models\AppSetting::put($user->avatarSettingKey(), $path);
        if ($old && $old !== $path) {
            \Illuminate\Support\Facades\Storage::disk('local')->delete($old);
        }
        ActivityLog::record('staff.photo', "Changed the profile photo of {$user->name}", 'user', ['userId' => $user->id]);

        return response()->json($this->format($user, $this->lastActivityByUser()));
    }

    /** DELETE /staff/{user}/avatar — back to the default (initials). */
    public function destroyAvatar(Request $request, User $user): JsonResponse
    {
        $this->authorizeManager($request, $user);
        $old = $user->avatarPath();
        \App\Models\AppSetting::query()->whereKey($user->avatarSettingKey())->delete();
        if ($old) {
            \Illuminate\Support\Facades\Storage::disk('local')->delete($old);
        }
        ActivityLog::record('staff.photo', "Removed the profile photo of {$user->name}", 'user', ['userId' => $user->id]);

        return response()->json($this->format($user, $this->lastActivityByUser()));
    }

    private function isSuperAdminActor(Request $request): bool
    {
        $actor = $request->user();

        return $actor
            && $actor->isSuperAdmin()
            && User::whereKey($actor->id)->value('status') === User::STATUS_ACTIVE;
    }

    /**
     * Super Admin: always. Admin: only with Role Access "Manage Staff", and
     * only for Staff accounts when a specific account is acted on.
     */
    private function authorizeManager(Request $request, ?User $target = null): void
    {
        if ($this->isSuperAdminActor($request)) {
            return;
        }
        $actor = $request->user();
        $isActiveAdmin = $actor
            && $actor->role === User::ROLE_ADMIN
            && User::whereKey($actor->id)->value('status') === User::STATUS_ACTIVE
            && \App\Services\RoleAccessService::allows($actor, 'staff.manage');
        abort_unless($isActiveAdmin, 403, 'You do not have access to Manage Staff.');
        abort_if($target !== null && $target->role !== User::ROLE_STAFF, 403, 'Admins can only manage Staff accounts.');
    }

    /** Block the action if it would remove the last active Super Admin. */
    private function ensureNotLastSuperAdmin(User $user, string $action): void
    {
        $otherActiveSupers = User::where('role', User::ROLE_SUPER_ADMIN)
            ->where('status', User::STATUS_ACTIVE)
            ->where('id', '!=', $user->id)
            ->count();

        if ($otherActiveSupers === 0) {
            throw ValidationException::withMessages([
                'user' => "This is the last active Super Admin — you cannot {$action} it.",
            ]);
        }
    }

    /**
     * Latest activity per user id (unix timestamp): the newer of their open
     * session and their latest activity-log entry (sign-in, stock change …).
     * Sessions are deleted at logout, so using them alone showed "Never" for
     * everyone who had logged out.
     */
    private function lastActivityByUser(): array
    {
        $latest = [];

        $logs = \App\Models\ActivityLog::query()
            ->whereNotNull('user_id')
            ->selectRaw('user_id, MAX(created_at) as last_at')
            ->groupBy('user_id')
            ->pluck('last_at', 'user_id');
        foreach ($logs as $userId => $at) {
            if ($at) {
                $latest[$userId] = \Illuminate\Support\Carbon::parse($at)->getTimestamp();
            }
        }

        if (config('session.driver') === 'database') {
            try {
                $sessions = DB::table(config('session.table', 'sessions'))
                    ->whereNotNull('user_id')
                    ->select('user_id', DB::raw('MAX(last_activity) as last_activity'))
                    ->groupBy('user_id')
                    ->pluck('last_activity', 'user_id');
                foreach ($sessions as $userId => $ts) {
                    $latest[$userId] = max((int) $ts, $latest[$userId] ?? 0);
                }
            } catch (\Illuminate\Database\QueryException) {
                // No sessions table: the activity log alone is enough.
            }
        }

        return $latest;
    }

    /** Shape a user for the Staffs tab (display-style role/status labels). */
    private function format(User $u, array $lastActivity): array
    {
        $roleLabels = [
            User::ROLE_SUPER_ADMIN => 'Super Admin',
            User::ROLE_ADMIN       => 'Admin',
            User::ROLE_STAFF       => 'Staff',
        ];

        $ts = $lastActivity[$u->id] ?? null;
        $photo = $u->avatarPath();

        return [
            'id'         => $u->id,
            'name'       => $u->name,
            'email'      => $u->email,
            'role'       => $roleLabels[$u->role] ?? 'Staff',
            'status'     => $u->status === User::STATUS_INACTIVE ? 'Inactive' : 'Active',
            'lastActive' => $ts ? $this->humanizeTimestamp((int) $ts) : 'Never',
            // null = no photo; the screen shows initials (the default picture).
            'avatarUrl'  => $photo ? "/staff/{$u->id}/avatar?v=".substr(md5($photo), 0, 10) : null,
        ];
    }

    private function humanizeTimestamp(int $unix): string
    {
        // Show times in the shop's time (Philippines), not the server's UTC.
        $timezone = config('app.business_timezone', 'Asia/Manila');
        $now = now($timezone);
        $at = \Illuminate\Support\Carbon::createFromTimestamp($unix)->setTimezone($timezone);
        $diff = abs($now->getTimestamp() - $unix);

        if ($diff < 60) return 'Just now';
        if ($diff < 3600) return floor($diff / 60).' min ago';
        // "Today" stays outside format(): inside it, PHP reads T, o, d, a, y as date codes.
        if ($at->isSameDay($now)) return 'Today · '.$at->format('h:i A');
        if ($at->isSameDay($now->copy()->subDay())) return 'Yesterday · '.$at->format('h:i A');

        return $at->diffForHumans();
    }
}

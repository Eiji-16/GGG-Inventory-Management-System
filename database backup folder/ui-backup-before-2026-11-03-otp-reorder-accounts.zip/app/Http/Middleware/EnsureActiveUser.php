<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class EnsureActiveUser
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();
        if ($user?->exists) {
            $user = $user->fresh();
        }
        if ($user === null) {
            Auth::guard('web')->logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();

            return response()->json(['message' => 'Unauthenticated.'], 401);
        }

        $sessionVersion = (int) $request->session()->get('_account_auth_version', 0);
        $versionChanged = $sessionVersion !== (int) $user->auth_version;
        if ($user->status !== 'active') {
            Auth::guard('web')->logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();

            return response()->json([
                'code' => 'account_deactivated',
                'message' => 'Your account has been deactivated by a Super Admin. You have been signed out. Please contact the Super Admin if you think this is a mistake.',
            ], 401);
        }

        if ($versionChanged) {
            Auth::guard('web')->logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();

            return response()->json(['message' => 'This account session is no longer active.'], 401);
        }

        $request->session()->put('_account_auth_version', (int) $user->auth_version);

        return $next($request);
    }
}

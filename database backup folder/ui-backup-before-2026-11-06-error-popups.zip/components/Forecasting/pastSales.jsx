import React, { useEffect, useMemo, useRef, useState } from 'react';
import { PageToast } from '../../utils/toast';
import apiFetch from '../../apiFetch';
import { readSalesFile, downloadTemplate, monthLabel } from '../../utils/pastSalesImport';
import CustomSelect from './CustomSelect';

/* Same search icon as Forecasting (expandable search box). */
const SearchIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
    <circle cx="11" cy="11" r="7" /><path d="M21 21l-4.3-4.3" />
  </svg>
);

/* ==========================================================================
   PAST SALES
   Monthly or weekly sales from BEFORE a product's Stock Control records begin (e.g.
   from the owner's old Excel sheets). Used only as forecasting history —
   it never changes stock on hand. Two ways in:
     1. Import from Excel (many products at once, with a preview first)
     2. Enter manually (one product: 12-month grid, or the weeks of a month)
   Monthly entries feed the month/year forecasts; weekly entries feed the
   weekly forecast. A month with no monthly entry also uses its weeks, once
   every week of it is entered (border weeks split by days). A month can't be
   split into weeks, so monthly entries never feed the weekly forecast.
   ========================================================================== */

const MONTH_SHORT = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MAX_IMPORT_ROWS = 60000;
const MAX_MANUAL_SALES_UNITS = 9999;

const formatUnits = (value) => Number(value).toLocaleString(undefined, { maximumFractionDigits: 11 });

async function requestJson(url, options = {}) {
  const response = await apiFetch(url, {
    ...options,
    headers: {
      Accept: 'application/json',
      ...(options.body ? { 'Content-Type': 'application/json' } : {}),
      ...options.headers,
    },
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const validationMessage = data.errors ? Object.values(data.errors).flat()[0] : null;
    throw new Error(validationMessage || data.message || `Request failed (${response.status}).`);
  }
  return data;
}

const loadXlsx = async () => (await import('xlsx-js-style')).default;
const currentMonthKey = () => {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
};

/* ===== WEEK HELPERS (local dates, Monday-start weeks like the forecast) ===== */
const pad2 = (n) => String(n).padStart(2, '0');
const dateKey = (d) => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
const parseKey = (key) => { const [y, m, d] = key.split('-').map(Number); return new Date(y, m - 1, d); };
const currentWeekKey = () => {
  const d = new Date();
  d.setDate(d.getDate() - ((d.getDay() + 6) % 7));   // back to Monday
  return dateKey(d);
};
/* The weeks whose Monday falls in the given month (4 or 5 weeks). */
const weeksOfMonth = (year, monthIndex) => {
  const d = new Date(year, monthIndex, 1);
  d.setDate(d.getDate() + ((8 - d.getDay()) % 7));   // first Monday on/after the 1st
  const weeks = [];
  while (d.getMonth() === monthIndex) {
    const end = new Date(d); end.setDate(end.getDate() + 6);
    weeks.push({ key: dateKey(d), start: new Date(d), end });
    d.setDate(d.getDate() + 7);
  }
  return weeks;
};
const shortDate = (d) => `${MONTH_SHORT[d.getMonth()]} ${d.getDate()}`;

/* ===== IMPORT FROM EXCEL ===== */
function ImportCard({ products, onImported }) {
  const fileRef = useRef(null);
  const [fileName, setFileName] = useState('');
  const [parsed, setParsed] = useState(null);
  const [preview, setPreview] = useState(null);
  const [status, setStatus] = useState('idle'); // idle | reading | previewing | ready | importing
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [issueFilter, setIssueFilter] = useState('error');

  const reset = () => {
    setParsed(null);
    setPreview(null);
    setFileName('');
    setStatus('idle');
    setError('');
    if (fileRef.current) fileRef.current.value = '';
  };

  const handleTemplate = async () => {
    setError('');
    try {
      downloadTemplate(await loadXlsx(), products);
    } catch (templateError) {
      console.error('Could not create the template:', templateError);
      setError('The template could not be created. Please refresh the page and try again.');
    }
  };

  const handleFile = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    reset();
    setSuccess('');
    setFileName(file.name);
    setStatus('reading');
    let result;
    try {
      result = await readSalesFile(await loadXlsx(), file);
    } catch (readError) {
      console.error('Could not read the sales file:', readError);
      setStatus('idle');
      setError('This file could not be read. Open it in Excel, save it as .xlsx (or .csv), and try again.');
      return;
    }
    setParsed(result);
    if (!result.rows.length) {
      setStatus('idle');
      setError(result.notes[0] || 'No sales rows were found in this file.');
      return;
    }
    if (result.rows.length > MAX_IMPORT_ROWS) {
      setStatus('idle');
      setError(`This file has ${result.rows.length.toLocaleString()} rows. Split it into files of up to ${MAX_IMPORT_ROWS.toLocaleString()} rows.`);
      return;
    }
    setStatus('previewing');
    try {
      const data = await requestJson('/api/past-sales/import', {
        method: 'POST',
        body: JSON.stringify({ rows: result.rows, commit: false }),
      });
      setPreview(data);
      setIssueFilter(data.summary.errors ? 'error' : 'skipped');
      setStatus('ready');
    } catch (previewError) {
      setStatus('idle');
      setError(previewError.message || 'The rows could not be checked. Please try again.');
    }
  };

  const handleImport = async () => {
    if (!parsed?.rows?.length) return;
    setStatus('importing');
    setError('');
    try {
      const data = await requestJson('/api/past-sales/import', {
        method: 'POST',
        body: JSON.stringify({ rows: parsed.rows, commit: true }),
      });
      const message = `Imported ${data.saved.toLocaleString()} month${data.saved === 1 ? '' : 's'} of past sales for ${data.summary.products.toLocaleString()} product${data.summary.products === 1 ? '' : 's'} from ${fileName}.`;
      reset();
      setSuccess(message);
      onImported?.();
    } catch (importError) {
      setStatus('ready');
      setError(importError.message || 'The import failed. Nothing was saved.');
    }
  };

  const issues = (preview?.issues || []).filter((issue) => issue.type === issueFilter);
  const busy = status === 'reading' || status === 'previewing' || status === 'importing';

  return (
    <section className="fx-card ps-card">
      <header className="fx-card-head">
        <div className="fx-title">
          <h2>Import from Excel</h2>
          <p>For many products at once — use her existing Excel sheet or the template. (Excel import is for monthly sales; weekly sales are entered below.)</p>
        </div>
      </header>

      <ol className="ps-steps">
        <li>
          <strong>Get the sheet ready.</strong> Either <button type="button" className="ps-link" onClick={handleTemplate}>download the template</button> (all
          products, last 12 months across), or use her own sheet with columns like <em>Product · Month · Units Sold</em>, or
          <em> Product · Jan 2026 · Feb 2026 …</em>
        </li>
        <li>
          <strong>Upload it.</strong> The system reads the first sheet and shows a preview — nothing is saved yet.
          <div className="ps-upload-row">
            <label className={`f-btn f-btn-primary ps-upload${busy ? ' is-disabled' : ''}`}>
              <input
                ref={fileRef}
                type="file"
                accept=".xlsx,.xls,.csv"
                onChange={handleFile}
                disabled={busy}
                aria-label="Choose an Excel or CSV file"
              />
              {status === 'reading' ? 'Reading file…' : status === 'previewing' ? 'Checking rows…' : 'Choose Excel file'}
            </label>
            {fileName && <span className="ps-file-name">{fileName}</span>}
          </div>
        </li>
        <li><strong>Check the preview, then click Import.</strong></li>
      </ol>

      {error && <p className="fx-warning" role="alert">{error}</p>}
      <PageToast message={success} type="success" onShown={() => setSuccess('')} />

      {preview && parsed && (
        <div className="ps-preview">
          {parsed.notes?.[0] && <p className="ps-detected">{parsed.notes[0]}</p>}
          <div className="ps-stats">
            <div><span>Rows read</span><strong>{preview.summary.rowsRead.toLocaleString()}</strong></div>
            <div className="is-good"><span>Months ready</span><strong>{preview.summary.readyMonths.toLocaleString()}</strong></div>
            <div><span>Products</span><strong>{preview.summary.products.toLocaleString()}</strong></div>
            <div><span>Units</span><strong>{formatUnits(preview.summary.totalUnits)}</strong></div>
            <div className={preview.summary.skipped ? 'is-warn' : ''}><span>Skipped</span><strong>{preview.summary.skipped.toLocaleString()}</strong></div>
            <div className={preview.summary.errors ? 'is-bad' : ''}><span>Errors</span><strong>{preview.summary.errors.toLocaleString()}</strong></div>
          </div>

          {(preview.summary.errors > 0 || preview.summary.skipped > 0) && (
            <div className="ps-issues">
              <div className="fx-segmented" role="tablist" aria-label="Problem type">
                <button type="button" role="tab" aria-selected={issueFilter === 'error'} className={issueFilter === 'error' ? 'is-active' : ''} onClick={() => setIssueFilter('error')}>
                  Errors ({preview.summary.errors})
                </button>
                <button type="button" role="tab" aria-selected={issueFilter === 'skipped'} className={issueFilter === 'skipped' ? 'is-active' : ''} onClick={() => setIssueFilter('skipped')}>
                  Skipped ({preview.summary.skipped})
                </button>
              </div>
              <p className="ps-issue-help">
                {issueFilter === 'error'
                  ? 'These rows will not be imported. Fix them in Excel and upload again, or import the rest now.'
                  : 'These months are left out on purpose so nothing is counted twice.'}
              </p>
              <div className="fx-table-wrap ps-scroll">
                <table className="fx-table">
                  <thead><tr><th>Excel row</th><th>Product</th><th>Month</th><th>Reason</th></tr></thead>
                  <tbody>
                    {issues.length === 0
                      ? <tr><td colSpan={4} className="fx-empty">None.</td></tr>
                      : issues.map((issue, index) => (
                        <tr key={`${issue.row}-${issue.month}-${index}`}>
                          <td>{issue.row ?? '—'}</td>
                          <td>{issue.product || '—'}</td>
                          <td>{/^\d{4}-\d{2}$/.test(issue.month) ? monthLabel(issue.month) : (issue.month || '—')}</td>
                          <td>{issue.message}</td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {preview.ready.length > 0 && (
            <details className="ps-ready" open={preview.summary.errors === 0}>
              <summary>Preview of what will be saved ({preview.summary.readyMonths.toLocaleString()} months)</summary>
              <div className="fx-table-wrap ps-scroll">
                <table className="fx-table">
                  <thead><tr><th>Product</th><th>Month</th><th className="fx-num">Units Sold</th></tr></thead>
                  <tbody>
                    {preview.ready.map((row) => (
                      <tr key={`${row.productId}-${row.month}`}>
                        <td>{row.product} <small className="ps-muted">{row.productId}</small></td>
                        <td>{monthLabel(row.month)}</td>
                        <td className="fx-num">
                          {formatUnits(row.unitsSold)}
                          {row.rows > 1 && <small className="ps-muted"> ({row.rows} rows added)</small>}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {preview.summary.readyMonths > preview.ready.length && (
                <p className="ps-muted">Showing the first {preview.ready.length} of {preview.summary.readyMonths.toLocaleString()}.</p>
              )}
            </details>
          )}

          <div className="fx-actions">
            <button type="button" className="f-btn f-btn-primary" onClick={handleImport} disabled={status !== 'ready' || preview.summary.readyMonths === 0}>
              {status === 'importing' ? 'Importing…' : `Import ${preview.summary.readyMonths.toLocaleString()} month${preview.summary.readyMonths === 1 ? '' : 's'}`}
            </button>
            <button type="button" className="f-btn f-btn-ghost" onClick={reset} disabled={status === 'importing'}>Cancel</button>
          </div>
        </div>
      )}
    </section>
  );
}

/* ===== ENTER MANUALLY (one product, 12-month grid) ===== */
function ManualCard({ products, productId, onProductChange, onSaved }) {
  const [search, setSearch] = useState('');
  const [periodType, setPeriodType] = useState('month'); // 'month' | 'week'
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [year, setYear] = useState(null);
  const [monthIndex, setMonthIndex] = useState(0);        // weekly mode: which month's weeks
  const [drafts, setDrafts] = useState({});
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  const matches = useMemo(() => {
    const q = search.trim().toLowerCase();
    return !q ? products : products.filter((p) =>
      [p.name, p.id, p.brand, p.category, ...(p.variants || [])]
        .some((v) => String(v || '').toLowerCase().includes(q)));
  }, [products, search]);

  const filtered = useMemo(() => {
    const list = matches;
    if (productId && !list.some((p) => p.id === productId)) {
      const selected = products.find((p) => p.id === productId);
      return selected ? [selected, ...list] : list;
    }
    return list;
  }, [products, matches, productId]);

  useEffect(() => {
    const query = search.trim().toLowerCase();
    if (!query) return;
    const exactMatches = matches.filter((p) =>
      [p.name, p.id].some((value) => String(value || '').trim().toLowerCase() === query));
    const match = exactMatches.length === 1 ? exactMatches[0]
      : matches.length === 1 ? matches[0] : null;
    if (match && String(match.id) !== String(productId)) onProductChange(String(match.id));
  }, [search, matches, onProductChange]);

  useEffect(() => {
    setData(null);
    setDrafts({});
    setError('');
    setNotice('');
    if (!productId) return undefined;
    let active = true;
    setLoading(true);
    requestJson(`/api/past-sales?product=${encodeURIComponent(productId)}&periodType=${periodType}`, { cache: 'no-store' })
      .then((result) => {
        if (!active) return;
        setData(result);
        if (periodType === 'week') {
          // Open on the month of the last week that can still be entered.
          const lastAllowed = parseKey(result.cutoff);
          lastAllowed.setDate(lastAllowed.getDate() - 7);
          setYear(lastAllowed.getFullYear());
          setMonthIndex(lastAllowed.getMonth());
        } else {
          const cutoffYear = Number(result.cutoff.slice(0, 4));
          const cutoffMonth = Number(result.cutoff.slice(5, 7));
          setYear(cutoffMonth === 1 ? cutoffYear - 1 : cutoffYear);
        }
      })
      .catch((loadError) => { if (active) setError(loadError.message || 'Could not load past sales.'); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [productId, periodType]);

  const isWeekly = periodType === 'week';
  const saved = useMemo(
    () => Object.fromEntries((data?.rows || []).map((row) => [isWeekly ? row.week : row.month, row.unitsSold])),
    [data, isWeekly],
  );
  // Data loaded for the other mode while switching: wait for the right one.
  const dataReady = data && (data.periodType || 'month') === periodType;
  const cutoff = data?.cutoff || (isWeekly ? currentWeekKey() : currentMonthKey());
  const cutoffYear = Number(cutoff.slice(0, 4));
  const years = Array.from({ length: 6 }, (_, i) => cutoffYear - i);
  /* The boxes to show: 12 months of the year, or the weeks of one month. */
  const cells = !year || !dataReady ? [] : isWeekly
    ? weeksOfMonth(year, monthIndex).map(({ key, start, end }) => ({
        key,
        label: `${shortDate(start)} – ${shortDate(end)}`,
        title: `Week of ${shortDate(start)}, ${start.getFullYear()}`,
        locked: key >= cutoff,
        unfinished: key >= currentWeekKey(),
      }))
    : MONTH_SHORT.map((label, i) => {
        const key = `${year}-${String(i + 1).padStart(2, '0')}`;
        return { key, label: `${label} ${year}`, title: `${label} ${year}`, locked: key >= cutoff, unfinished: key >= currentMonthKey() };
      });
  const unitWord = isWeekly ? 'week' : 'month';
  const valueFor = (key) => (key in drafts ? drafts[key] : (saved[key] ?? ''));
  const handleUnitsChange = (key, value) => {
    if (value !== '' && Number(value) > MAX_MANUAL_SALES_UNITS) {
      setError(`Enter a quantity from 0 to ${MAX_MANUAL_SALES_UNITS.toLocaleString()}.`);
      return;
    }
    setError('');
    setDrafts((current) => ({ ...current, [key]: value }));
  };
  /* Monthly mode: the month totals worked out from the weekly entries. */
  const weekTotals = useMemo(
    () => (isWeekly ? {} : Object.fromEntries((data?.fromWeeks || []).map((row) => [row.month, row]))),
    [data, isWeekly],
  );
  const dirty = cells.some(({ key, locked }) => !locked && key in drafts && String(drafts[key]) !== String(saved[key] ?? ''));

  const save = async () => {
    const records = [];
    for (const { key, title, locked } of cells) {
      if (locked || !(key in drafts)) continue;
      const text = String(drafts[key]).trim();
      if (text === String(saved[key] ?? '')) continue;
      const units = text === '' ? null : text;
      if (units !== null && (!/^\d+(?:\.\d{1,11})?$/.test(units) || Number(units) > MAX_MANUAL_SALES_UNITS)) {
        setError(`${title}: enter a quantity from 0 to ${MAX_MANUAL_SALES_UNITS.toLocaleString()} with up to 11 decimal places, or leave it blank.`);
        return;
      }
      records.push(isWeekly ? { week: key, unitsSold: units } : { month: key, unitsSold: units });
    }
    if (!records.length) return;
    setSaving(true);
    setError('');
    try {
      const result = await requestJson('/api/past-sales', {
        method: 'PUT',
        body: JSON.stringify(isWeekly ? { productId, periodType: 'week', records } : { productId, records }),
      });
      setData(result);
      setDrafts({});
      setNotice(`Saved ${records.length} ${unitWord}${records.length === 1 ? '' : 's'} for ${result.productName}. The ${isWeekly ? 'weekly' : 'monthly and yearly'} forecast now includes them.`);
      onSaved?.();
    } catch (saveError) {
      setError(saveError.message || 'Could not save past sales.');
    } finally {
      setSaving(false);
    }
  };

  const product = products.find((p) => p.id === productId);
  const cutoffText = isWeekly ? `the week of ${shortDate(parseKey(cutoff))}, ${cutoff.slice(0, 4)}` : monthLabel(cutoff);

  return (
    <section className="fx-card ps-card">
      <header className="fx-card-head">
        <div className="fx-title">
          <h2>Enter manually</h2>
          <p>For one product — type the units sold per {isWeekly ? 'week' : 'month'}.</p>
        </div>
        {/* Monthly entries feed the month/year forecast; weekly entries feed the weekly forecast. */}
        <div className="fx-segmented ps-period-toggle" role="tablist" aria-label="Enter sales per">
          {[['month', 'Monthly'], ['week', 'Weekly']].map(([value, label]) => (
            <button
              key={value}
              type="button"
              role="tab"
              aria-selected={periodType === value}
              className={periodType === value ? 'is-active' : ''}
              disabled={saving}
              onClick={() => { if (value !== periodType) { setPeriodType(value); setDrafts({}); setNotice(''); setError(''); } }}
            >
              {label}
            </button>
          ))}
        </div>
      </header>

      <div className={`ps-manual-controls${isWeekly ? ' is-weekly' : ''}`}>
        <div className="f-field ps-find-field f-search-wrap xs-search">
          <label htmlFor="ps-search">Find product</label>
          <input autoComplete="off" id="ps-search" type="text" aria-label="Find product" placeholder="Name, ID or category…" value={search} onChange={(e) => setSearch(e.target.value)} />
          <SearchIcon />
        </div>
        <div className="f-field f-grow ps-product-field">
          <label htmlFor="ps-product">Product</label>
          <CustomSelect
            id="ps-product"
            value={productId || ''}
            placeholder="Select a product…"
            emptyText="No products match"
            options={filtered.slice(0, 500).map((p) => ({ value: p.id, label: p.name, sub: p.id }))}
            onChange={(value) => onProductChange(value)}
          />
        </div>
        <div className="f-field ps-year-field">
          <label htmlFor="ps-year">Year</label>
          <CustomSelect
            id="ps-year"
            className={isWeekly ? '' : 'cs-align-right'}
            value={year ?? ''}
            disabled={!dataReady}
            options={years.map((y) => ({ value: y, label: String(y) }))}
            onChange={(value) => { setYear(Number(value)); setDrafts({}); }}
          />
        </div>
        {isWeekly && (
          <div className="f-field ps-month-field">
            <label htmlFor="ps-month">Month</label>
            <CustomSelect
              id="ps-month"
              className="cs-align-right"
              value={monthIndex}
              disabled={!dataReady}
              options={MONTH_SHORT.map((label, i) => ({ value: i, label }))}
              onChange={(value) => { setMonthIndex(Number(value)); setDrafts({}); }}
            />
          </div>
        )}
      </div>

      {dataReady && (
        <p className="ps-detected">
          {data.recordingStart
            ? <>Stock Control records for <strong>{product?.name || data.productName}</strong> begin {isWeekly ? <>on <strong>{shortDate(parseKey(data.recordingStart))}, {data.recordingStart.slice(0, 4)}</strong></> : <>in <strong>{monthLabel(data.recordingStart)}</strong></>}, so past sales can be entered up to the {unitWord} before.</>
            : <>No Stock Control records for <strong>{product?.name || data.productName}</strong> yet — any finished {unitWord} before {cutoffText} can be entered.</>}
          {isWeekly && ' Weeks run Monday to Sunday, the same as the weekly forecast.'}
        </p>
      )}

      {loading ? <p className="ps-muted">Loading…</p> : dataReady && (
        <div className={`ps-grid${isWeekly ? ' ps-grid-weeks' : ''}`}>
          {cells.map(({ key, label, title, locked, unfinished }) => {
            const weeks = !locked ? weekTotals[key] : null;
            const typed = String(valueFor(key)).trim();
            // Auto: no monthly number, and every week of this month is entered.
            const auto = weeks && weeks.complete && typed === '';
            const mismatch = weeks && weeks.complete && typed !== '' && Number(typed) !== weeks.unitsSold;
            return (
              <label key={key} className={`ps-month${locked ? ' is-locked' : ''}${saved[key] !== undefined ? ' has-value' : ''}${auto ? ' is-auto' : ''}${mismatch ? ' is-mismatch' : ''}`} title={title}>
                <span>{label}</span>
                {locked ? (
                  <em>{unfinished ? 'Not finished' : 'From Stock Control'}</em>
                ) : (
                  <input
                    type="number"
                    min="0"
                    max={MAX_MANUAL_SALES_UNITS}
                    step="any"
                    inputMode="decimal"
                    placeholder={auto ? String(weeks.unitsSold) : '—'}
                    value={valueFor(key)}
                    onChange={(e) => handleUnitsChange(key, e.target.value)}
                    aria-label={`${title} units sold`}
                  />
                )}
                {weeks && (
                  <small
                    className="ps-week-note"
                    title={weeks.complete
                      ? `Total of the weekly entries for ${title}. Weeks that cross into another month are split by days.`
                      : `${weeks.weeksEntered} of the ${weeks.weeksNeeded} weeks of ${title} have weekly entries — enter all of them to use the weekly total.`}
                  >
                    {auto ? `Weekly total used`
                      : mismatch ? `⚠ Weeks total ${formatUnits(weeks.unitsSold)}`
                      : weeks.complete ? 'Matches weeks ✓'
                      : `Weeks: ${weeks.weeksEntered} of ${weeks.weeksNeeded} entered`}
                  </small>
                )}
              </label>
            );
          })}
        </div>
      )}

      {error && <p className="fx-warning" role="alert">{error}</p>}
      <PageToast message={notice} type="success" onShown={() => setNotice('')} />

      <div className="fx-actions">
        <button type="button" className="f-btn f-btn-primary" onClick={save} disabled={!dirty || saving}>
          {saving ? 'Saving…' : `Save ${unitWord}s`}
        </button>
        {dirty && <button type="button" className="f-btn f-btn-ghost" onClick={() => setDrafts({})} disabled={saving}>Undo changes</button>}
      </div>
      <p className="ps-muted hint-text">Leave a {unitWord} blank if there is no record. Clearing a saved {unitWord} and saving removes it.{isWeekly
        ? ' Weekly entries are used by the weekly forecast. Once every week of a month is entered, its total is also used for that month (if it has no monthly entry).'
        : ' A blank month whose weeks are all entered uses the total of its weeks; a typed monthly number always takes priority.'}</p>
    </section>
  );
}

export default function PastSalesPanel({ products, productId, onProductChange, onChanged }) {
  return (
    <div className="fx-layout">
      <section className="fx-card ps-intro">
        <div className="fx-title">
          <h2>Past Sales</h2>
          <p>
            Monthly or weekly sales from <strong>before</strong> a product was recorded in Stock Control — for example from the owner’s old Excel sheets.
            They give the forecast history to work with right away. They are only used for forecasting and never change stock on hand.
            From the month (or week) a product’s Stock Control records begin, its sales come from Stock Out transactions instead, so nothing is counted twice. Monthly entries are used by the monthly and yearly forecast; weekly entries by the weekly forecast — and by a month with no monthly entry once all its weeks are entered.
          </p>
        </div>
      </section>
      <ImportCard products={products} onImported={onChanged} />
      <ManualCard products={products} productId={productId} onProductChange={onProductChange} onSaved={onChanged} />
    </div>
  );
}

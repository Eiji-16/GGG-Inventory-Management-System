import { useEffect, useState } from 'react';

/* ===== ROWS THAT FIT =====
   Works out how many table rows fit inside a table box without scrolling,
   so each page of the table fills the box exactly (no empty space under the
   last row). Used with useFillToBottom, which gives the box its height.

   How: box height − column-title row height, divided by one row's height.
   Re-measures when the box changes size (window resized, banner shown) and
   whenever `deps` change (e.g. the table switched view or finished loading).

   Phones show cards instead of a table, so they get a fixed page size. */
const DESKTOP = '(min-width: 901px)';

export default function useRowsThatFit(element, { min = 5, fallback = 20, deps = [] } = {}) {
  const [size, setSize] = useState(fallback);

  useEffect(() => {
    if (!element || typeof window === 'undefined') return undefined;
    let frame = 0;

    const measure = () => {
      frame = 0;
      if (element.offsetParent === null) return;          // page is hidden
      if (!window.matchMedia(DESKTOP).matches) {           // phone card layout
        setSize((prev) => (prev === fallback ? prev : fallback));
        return;
      }
      // A normal data row (skip "Loading…" / "No rows" messages that span all columns).
      const row = Array.from(element.querySelectorAll('tbody tr'))
        .find((tr) => !tr.querySelector('td[colspan]'));
      const rowHeight = row ? row.getBoundingClientRect().height : 0;
      if (!rowHeight) return;
      const headHeight = element.querySelector('thead')?.getBoundingClientRect().height || 0;
      const fits = Math.max(min, Math.floor((element.clientHeight - headHeight) / rowHeight));
      setSize((prev) => (prev === fits ? prev : fits));
    };
    const schedule = () => {
      if (!frame) frame = window.requestAnimationFrame(measure);
    };

    schedule();
    window.addEventListener('resize', schedule);
    const observer = typeof ResizeObserver === 'function' ? new ResizeObserver(schedule) : null;
    observer?.observe(element);

    return () => {
      window.removeEventListener('resize', schedule);
      observer?.disconnect();
      if (frame) window.cancelAnimationFrame(frame);
    };
  }, [element, min, fallback, ...deps]);

  return size;
}

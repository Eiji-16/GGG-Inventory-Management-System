import { useState, useEffect, useMemo } from 'react';
import { createPortal } from 'react-dom';
import { Download, FileText, X, ChevronRight } from 'lucide-react';
import './reports.css';
import exportReportWorkbook, { printReportPdf } from '../../utils/exportReportWorkbook';
import { useCurrency } from '../../CurrencyContext';
import useFillToBottom from '../../utils/fillToBottom';

/* ===== REPORTS & ANALYTICS: ONE OVERALL REPORT =====
   One page, no tabs. It shows the overall picture of the system's data:
     - 8 summary cards (two rows of four), and
     - 2 charts: weekly Stock In vs Stock Out, and fast vs slow moving products.
   Every card and chart can be clicked: it opens that specific report in a
   pop-up with all of its rows and its own Export PDF / Export Excel.
   "Export full report" puts every report into one file.
   Role Access (Settings) still decides which reports a role can see: the
   server leaves hidden ones out of /api/reports, so their cards don't show. */

/* Status/urgency/confidence → badge colour. */
const BADGE = {
  'In Stock': 'r-badge-good', Healthy: 'r-badge-good', High: 'r-badge-good',
  'Low Stock': 'r-badge-bad', Critical: 'r-badge-bad', Low: 'r-badge-warn',
  'Out of Stock': 'r-badge-bad', 'Slow Mover': 'r-badge-bad',
  'Fast-Moving': 'r-badge-good', 'Slow-Moving': 'r-badge-bad',
  Aging: 'r-badge-warn', Watch: 'r-badge-warn', Medium: 'r-badge-warn', Unknown: 'r-badge-warn',
};
const Badge = ({ label }) => (
  <span className={`r-badge ${BADGE[label] || 'r-badge-warn'}`}><span className="r-dot" />{label}</span>
);

/* Shared empty/loading row. */
const EmptyRow = ({ cols, text }) => (
  <tr><td colSpan={cols} style={{ textAlign: 'center', padding: '18px', color: 'var(--text-muted, #888)' }}>{text}</td></tr>
);

const sumBy = (rows, key) => rows.reduce((total, row) => total + (Number(row[key]) || 0), 0);

/* ===== CHART: weekly Stock In vs Stock Out (Bar / Line) ===== */
function MovementLineChart({ rows, maxVal }) {
  const width = 600;
  const height = 200;
  const pad = { top: 12, right: 12, bottom: 24, left: 12 };
  const innerW = width - pad.left - pad.right;
  const innerH = height - pad.top - pad.bottom;
  const x = (i) => pad.left + (rows.length === 1 ? innerW / 2 : (i / (rows.length - 1)) * innerW);
  const y = (v) => pad.top + innerH - (v / maxVal) * innerH;
  const path = (key) => rows.map((r, i) => `${i === 0 ? 'M' : 'L'}${x(i).toFixed(1)},${y(r[key]).toFixed(1)}`).join(' ');

  return (
    <svg className="r-line-chart" viewBox={`0 0 ${width} ${height}`} role="img" aria-label="Weekly stock in and stock out line chart">
      <line x1={pad.left} x2={width - pad.right} y1={pad.top + innerH} y2={pad.top + innerH} className="r-line-axis" />
      <path d={path('in')} className="r-line r-line-in" />
      <path d={path('out')} className="r-line r-line-out" />
      {rows.map((r, i) => (
        <g key={r.weekStart || i}>
          <circle cx={x(i)} cy={y(r.in)} r="3.5" className="r-line-dot r-line-in"><title>{`Week of ${r.period}: +${r.in} in`}</title></circle>
          <circle cx={x(i)} cy={y(r.out)} r="3.5" className="r-line-dot r-line-out"><title>{`Week of ${r.period}: −${r.out} out`}</title></circle>
          <text x={x(i)} y={height - 6} textAnchor="middle" className="r-line-label">{r.period}</text>
        </g>
      ))}
    </svg>
  );
}

/* A card or chart that opens its report when clicked (or Enter / Space). */
const clickableProps = (onOpen, label) => (onOpen ? {
  role: 'button',
  tabIndex: 0,
  'aria-label': `Open ${label}`,
  onClick: onOpen,
  onKeyDown: (event) => {
    if (event.target !== event.currentTarget) return;
    if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); onOpen(); }
  },
} : {});

const OpenHint = () => (
  <span className="r-open-hint" aria-hidden="true">View report <ChevronRight size={12} /></span>
);

function MovementChartCard({ rows, loading, onOpen }) {
  const [chartType, setChartType] = useState('bar');
  const maxVal = Math.max(1, ...rows.map((r) => Math.max(r.in, r.out)));
  // The Bar / Line switch changes the chart only; it doesn't open the report.
  const pick = (type) => (event) => { event.stopPropagation(); setChartType(type); };
  return (
    <div className="r-chart-card r-overall-chart r-clickable" {...clickableProps(onOpen, 'Stock Movement report')}>
      <div className="r-chart-card-head">
        <h3>Stock In vs Stock Out — last {rows.length || 8} weeks</h3>
        <div className="r-chart-head-right">
          <div className="r-toggle-group">
            <button type="button" className={chartType === 'bar' ? 'active' : ''} onClick={pick('bar')}>Bar</button>
            <button type="button" className={chartType === 'line' ? 'active' : ''} onClick={pick('line')}>Line</button>
          </div>
          {onOpen && <OpenHint />}
        </div>
      </div>
      {rows.length === 0 ? (
        <div className="r-chart-placeholder">{loading ? 'Loading…' : 'No movement data yet.'}</div>
      ) : chartType === 'line' ? (
        <MovementLineChart rows={rows} maxVal={maxVal} />
      ) : (
        <div className="r-mini-chart">
          {rows.map((r, i) => (
            <div className="r-mini-col" key={r.weekStart || i} title={`Week of ${r.period}: +${r.in} in / −${r.out} out`}>
              <div className="r-mini-bars">
                <span className="r-mini-bar r-mini-in" style={{ height: `${(r.in / maxVal) * 100}%` }} />
                <span className="r-mini-bar r-mini-out" style={{ height: `${(r.out / maxVal) * 100}%` }} />
              </div>
              <span className="r-mini-label">{r.period}</span>
            </div>
          ))}
        </div>
      )}
      <div className="r-chart-legend">
        <span><i className="r-legend-swatch r-mini-in" /> Stock In</span>
        <span><i className="r-legend-swatch r-mini-out" /> Stock Out</span>
      </div>
    </div>
  );
}

/* ===== CHART: fast vs slow moving products (horizontal bars) ===== */
function MovementBars({ title, items, tone, emptyText, onOpen }) {
  const max = Math.max(1, ...items.map((item) => item.unitsSold));
  return (
    <div className="r-chart-card r-fs-card r-overall-chart r-clickable" {...clickableProps(onOpen, 'Fast & Slow Moving Products report')}>
      <div className="r-chart-card-head"><h3>{title}</h3>{onOpen && <OpenHint />}</div>
      {items.length === 0 ? (
        <div className="r-fs-empty">{emptyText}</div>
      ) : (
        <ul className="r-fs-list">
          {items.map((item) => (
            <li key={item.productId || item.product} className="r-fs-row">
              <span className="r-fs-name" title={item.product}>{item.product}</span>
              <span className="r-fs-track">
                <span className={`r-fs-bar r-fs-${tone}`} style={{ width: `${Math.max(2, (item.unitsSold / max) * 100)}%` }} />
              </span>
              <span className="r-fs-value">{item.unitsSold}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

/* ===== SECTIONS (the same rows go on screen and into the export) ===== */
function buildSections(report, formatCurrency) {
  const sections = [];
  const add = (key, title, note, headers, rows, emptyText) => sections.push({ key, title, note, headers, rows, emptyText });

  if (report?.stockSummary) {
    add('stockSummary', 'Stock Summary', 'Current stock level, value and status of every product. Value uses the latest Stock In price.',
      ['Product', 'Category', 'Stock', 'Unit Cost', 'Value', 'Status'],
      (report.stockSummary.rows || []).map((r) => [
        r.product, r.category, r.stock,
        r.unitCost != null ? formatCurrency(r.unitCost) : '—',
        r.value != null ? formatCurrency(r.value) : '—',
        r.status,
      ]), 'No products found.');
  }
  if (report?.stockMovement) {
    add('stockMovement', 'Stock Movement', 'Units in and out per week (last 8 weeks, Monday start). Corrections are not included.',
      ['Week of', 'Stock In', 'Stock Out', 'Net Change'],
      (report.stockMovement.rows || []).map((r) => [r.period, r.in, r.out, `${r.net >= 0 ? '+' : ''}${r.net}`]),
      'No movements recorded yet.');
  }
  if (report?.topMoving) {
    add('topMoving', 'Top Moving Products', 'Ranked by units sold (Stock Out). Sales Value uses the selling price recorded on each sale.',
      ['Rank', 'Product', 'Units Sold', 'Sales Value'],
      (report.topMoving.rows || []).map((r) => [r.rank, `${r.product}${r.deleted ? ' (deleted)' : ''}`, r.unitsSold, formatCurrency(r.value)]),
      'No sales recorded yet.');
  }
  if (report?.fastSlowMoving) {
    const days = report.fastSlowMoving.windowDays || 90;
    add('fastSlowMoving', 'Fast & Slow Moving Products', `Units sold (Stock Out) in the last ${days} days.`,
      ['Movement', 'Rank', 'Product', 'Category', `Units Sold (${days} days)`, 'Current Stock'],
      (report.fastSlowMoving.rows || []).map((r) => [r.movement, r.rank, r.product, r.category, r.unitsSold, r.stock]),
      'No products to rank yet.');
  }
  if (report?.demandForecast) {
    add('demandForecast', 'Demand Forecast Summary', "Next month's forecast: 3-month Weighted Moving Average plus any active seasonal event.",
      ['Product', 'Current Stock', 'Forecasted Demand', 'Suggested Reorder', 'Confidence'],
      (report.demandForecast.rows || []).map((r) => [
        r.product, r.currentStock,
        `${r.forecastedDemand}${r.adjustmentPct ? ` (${r.adjustmentPct > 0 ? '+' : ''}${r.adjustmentPct}%)` : ''}`,
        r.suggestedReorder, r.confidence,
      ]), 'No completed month of sales yet — record Stock Out in Stock Control or add Past Sales in Forecasting.');
  }
  if (report?.autoCalculator) {
    add('autoCalculator', 'Economic Order Quantity Calculator Summary', 'Every Economic Order Quantity calculation logged to date.',
      ['Product', 'Product ID', 'Formula', 'Demand Source', 'Annual Demand', 'Result', 'Computed By', 'Date Computed'],
      (report.autoCalculator.rows || []).map((r) => [
        r.product || '—', r.productId || '—',
        r.formula === 'EOQ' ? 'Economic Order Quantity' : r.formula,
        r.demandSource === 'forecast' ? 'Forecast' : 'Historical',
        r.annualDemand != null ? `${Number(r.annualDemand).toLocaleString('en-PH')} units/year` : '—',
        r.result != null
          ? `${r.formula === 'EOQ'
            ? (r.recommendedOrderQuantity ?? Math.round(Number(r.result))).toLocaleString('en-PH')
            : r.result} ${r.unit || ''}`.trim()
          : '—',
        r.by || '—', r.date,
      ]), 'No calculations logged yet — use the Economic Order Quantity Calculator.');
  }
  if (report?.inventoryAging) {
    add('inventoryAging', 'Inventory Aging Report', 'Days since the latest Stock In (estimated from the creation date if there is none). Over 60 days = Aging, over 120 = Slow Mover.',
      ['Product', 'Days in Stock', 'Stock Level', 'Status'],
      (report.inventoryAging.rows || []).map((r) => [
        r.product,
        r.daysInStock == null ? '—' : `${r.daysInStock}${r.ageEstimated ? ' (est.)' : ''}`,
        r.stock, r.status,
      ]), 'No stock on hand to age.');
  }
  if (report?.reorderPoint) {
    add('reorderPoint', 'Reorder Point Report', 'Products at or below their reorder point (safety stock + daily sales × lead time).',
      ['Product', 'Current Stock', 'Reorder Point (Low at)', 'Critical at', 'Urgency'],
      (report.reorderPoint.rows || []).map((r) => [
        r.product, r.currentStock, `${r.reorderPoint}${r.mode === 'manual' ? ' (manual)' : ''}`, r.criticalPoint ?? '—', r.urgency,
      ]), 'All products are above their reorder point.');
  }
  return sections;
}

/* ===== SUMMARY CARDS (two rows of four; each opens a report) ===== */
function buildCards(report, formatCurrency) {
  const cards = [];
  const kpis = report?.stockSummary?.kpis;
  if (kpis) {
    cards.push({ key: 'products', report: 'stockSummary', label: 'Products', value: Number(kpis.productCount || 0).toLocaleString(), sub: `${Number(kpis.totalStock || 0).toLocaleString()} units in stock` });
    cards.push({
      key: 'value',
      report: 'stockSummary',
      label: 'Inventory Value',
      value: formatCurrency(kpis.inventoryValue),
      sub: `at latest Stock In price${kpis.unpricedProducts ? ` · ${kpis.unpricedProducts} without a price` : ''}`,
    });
  }
  if (report?.reorderPoint) {
    const rows = report.reorderPoint.rows || [];
    const out = kpis ? kpis.outOfStock || 0 : rows.filter((r) => Number(r.currentStock) <= 0).length;
    cards.push({ key: 'reorder', report: 'reorderPoint', label: 'To Reorder', value: rows.length.toLocaleString(), sub: `at or below reorder point · ${out} out of stock` });
  }
  if (report?.topMoving) {
    const rows = report.topMoving.rows || [];
    cards.push({ key: 'sold', report: 'topMoving', label: 'Units Sold', value: sumBy(rows, 'unitsSold').toLocaleString(), sub: `${rows.length} product${rows.length === 1 ? '' : 's'} sold` });
  }
  if (report?.stockMovement) {
    const rows = report.stockMovement.rows || [];
    cards.push({ key: 'received', report: 'stockMovement', label: 'Units Received', value: sumBy(rows, 'in').toLocaleString(), sub: `last ${rows.length || 8} weeks · ${sumBy(rows, 'out').toLocaleString()} sold` });
  }
  if (report?.demandForecast) {
    const rows = report.demandForecast.rows || [];
    cards.push({ key: 'forecast', report: 'demandForecast', label: 'Forecast Next Month', value: Math.round(sumBy(rows, 'forecastedDemand')).toLocaleString(), sub: `units across ${rows.length} product${rows.length === 1 ? '' : 's'}` });
  }
  if (report?.autoCalculator) {
    const rows = report.autoCalculator.rows || [];
    cards.push({ key: 'eoq', report: 'autoCalculator', label: 'Order Quantity Calculations', value: rows.length.toLocaleString(), sub: 'Economic Order Quantity results logged' });
  }
  if (report?.inventoryAging) {
    const rows = report.inventoryAging.rows || [];
    const aging = rows.filter((r) => r.status === 'Aging' || r.status === 'Slow Mover').length;
    cards.push({ key: 'aging', report: 'inventoryAging', label: 'Aging Stock', value: aging.toLocaleString(), sub: `of ${rows.length} product${rows.length === 1 ? '' : 's'} in stock (over 60 days)` });
  }
  return cards;
}

/* ===== EXPORT HELPERS (one report, or all of them) ===== */
const toExportSection = (section) => ({
  title: section.title,
  headers: section.headers,
  rows: section.rows.map((row) => row.map((cell) => (cell == null ? '' : cell))),
});

async function exportExcel({ title, subtitle, fileName, sections, summary, scope }) {
  const exportSections = sections.map(toExportSection);
  await exportReportWorkbook({
    title,
    subtitle,
    fileName,
    sections: exportSections,
    summary,
    scope,
    note: exportSections.every((s) => s.rows.length === 0) ? 'No report rows were available at the time of export.' : '',
    columnWidths: Array.from({ length: Math.max(1, ...exportSections.map((s) => s.headers.length)) }, () => 24),
  });
}

function exportPdf({ title, subtitle, sections, summary, scope }) {
  const exportSections = sections.map(toExportSection);
  const opened = printReportPdf({
    title,
    subtitle,
    summary,
    sections: exportSections,
    scope,
    note: exportSections.every((s) => s.rows.length === 0) ? 'No report rows were available at the time of export.' : '',
  });
  if (!opened) throw new Error('Allow pop-ups for this site to export the PDF.');
}

const fileNameOf = (title) => title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

/* ===== POP-UP: one report with all of its rows and its own export ===== */
function ReportModal({ section, canExport, onClose }) {
  const [exportError, setExportError] = useState('');

  useEffect(() => {
    const onKey = (event) => { if (event.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  const options = {
    title: section.title,
    subtitle: section.note,
    fileName: fileNameOf(section.title),
    sections: [section],
    summary: [{ label: 'Records', value: section.rows.length }],
    scope: 'All rows of this report as of the time of export.',
  };
  const handleExcel = async () => {
    setExportError('');
    try { await exportExcel(options); } catch (error) {
      console.error(`Could not export ${section.title}:`, error);
      setExportError('Export failed. Please try again.');
    }
  };
  const handlePdf = () => {
    setExportError('');
    try { exportPdf(options); } catch (error) {
      console.error(`Could not export ${section.title} as PDF:`, error);
      setExportError(error.message || 'PDF export failed. Please try again.');
    }
  };

  return createPortal(
    <div className="r-modal-overlay" onClick={onClose}>
      <div
        className="r-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="r-modal-title"
        onClick={(event) => event.stopPropagation()}
      >
        <div className="r-modal-header">
          <div className="r-panel-title">
            <h2 id="r-modal-title">{section.title}</h2>
            <p>{section.note}</p>
            {exportError && <p role="alert" className="r-modal-error">{exportError}</p>}
          </div>
          <div className="r-modal-actions">
            {canExport && (
              <>
                <button className="r-export-btn" type="button" onClick={handlePdf}>
                  <FileText size={13} /> Export PDF
                </button>
                <button className="r-export-btn" type="button" onClick={handleExcel}>
                  <Download size={13} /> Export Excel
                </button>
              </>
            )}
            <button type="button" className="r-modal-close" onClick={onClose} aria-label="Close" autoFocus>
              <X size={16} />
            </button>
          </div>
        </div>
        <div className="r-modal-body">
          <table className="r-table">
            <thead>
              <tr>{section.headers.map((header) => <th key={header}>{header}</th>)}</tr>
            </thead>
            <tbody>
              {section.rows.length === 0 ? <EmptyRow cols={section.headers.length} text={section.emptyText} />
                : section.rows.map((row, rowIndex) => (
                  <tr key={rowIndex}>
                    {row.map((cell, cellIndex) => (
                      <td key={cellIndex}>{BADGE[cell] ? <Badge label={cell} /> : cell}</td>
                    ))}
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
        <div className="r-modal-footer">
          {section.rows.length.toLocaleString()} {section.rows.length === 1 ? 'row' : 'rows'}
        </div>
      </div>
    </div>,
    document.body
  );
}

/* refreshKey changes whenever stock or products change elsewhere; isActive is
   true while the Reports page is on screen. The page stays mounted in the
   background, so it reloads on either (the main page checks for changes every
   few seconds). canTab(key) = Role Access for each report; canExport = may
   export. */
export default function ReportsAnalyticsDesign({ safetyStock, refreshKey = 0, isActive = true, canTab = () => true, canExport = true }) {
  const { formatCurrency } = useCurrency();
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [exportError, setExportError] = useState('');
  const [openKey, setOpenKey] = useState(null);   // which report's pop-up is open
  // The charts area stretches to the bottom of the page, so the left and right
  // columns end at the same line and nothing is cut off.
  const fillChartsToBottom = useFillToBottom();

  const anySectionAllowed = ['stock_summary', 'stock_movement', 'top_moving', 'fast_slow', 'demand_forecast', 'order_quantity', 'inventory_aging', 'reorder_point']
    .some((key) => canTab(key));

  useEffect(() => {
    if (!isActive) return undefined;
    let active = true;
    setLoading(true);
    setError('');
    fetch('/api/reports', { headers: { Accept: 'application/json' }, cache: 'no-store' })
      .then((r) => { if (!r.ok) throw new Error(`Could not load reports (${r.status}).`); return r.json(); })
      .then((data) => { if (active) setReport(data); })
      .catch((e) => { if (active) setError(e.message || 'Could not load reports.'); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [safetyStock, refreshKey, isActive]);

  const sections = useMemo(() => buildSections(report, formatCurrency), [report, formatCurrency]);
  const cards = useMemo(() => buildCards(report, formatCurrency), [report, formatCurrency]);
  const sectionByKey = useMemo(() => new Map(sections.map((section) => [section.key, section])), [sections]);
  const openSection = openKey ? sectionByKey.get(openKey) : null;
  const opener = (key) => (sectionByKey.has(key) ? () => setOpenKey(key) : null);

  const firstLoad = loading && !report;   // keep old numbers on screen while refreshing

  /* Export full report: every report, all rows, one file. */
  const fullOptions = {
    title: 'Overall Inventory Report',
    subtitle: 'All system data in one report: stock, movements, sales, forecasts, order quantities, aging and reorder needs',
    fileName: 'overall-inventory-report',
    sections,
    summary: cards.slice(0, 6).map(({ label, value }) => ({ label, value })),
    scope: 'Every report you have access to, with all of its rows, as of the time of export.',
  };
  const handleFullExcel = async () => {
    setExportError('');
    try { await exportExcel(fullOptions); } catch (exportFailure) {
      console.error('Could not export the overall report:', exportFailure);
      setExportError('Export failed. Please try again.');
    }
  };
  const handleFullPdf = () => {
    setExportError('');
    try { exportPdf(fullOptions); } catch (exportFailure) {
      console.error('Could not export the overall report as PDF:', exportFailure);
      setExportError(exportFailure.message || 'PDF export failed. Please try again.');
    }
  };

  /* "Export full report" buttons: bottom left, under the Stock In vs Out chart. */
  const fullExport = canExport ? (
    <div className="r-overall-toolbar">
      <button className="r-export-btn" type="button" onClick={handleFullPdf} disabled={firstLoad} title="Every report in one PDF">
        <FileText size={13} /> Export full report (PDF)
      </button>
      <button className="r-export-btn" type="button" onClick={handleFullExcel} disabled={firstLoad} title="Every report in one Excel file">
        <Download size={13} /> Export full report (Excel)
      </button>
      {exportError && <p role="alert" className="r-modal-error">{exportError}</p>}
    </div>
  ) : null;

  const movementRows = report?.stockMovement?.rows || [];
  const fastSlow = report?.fastSlowMoving;

  if (!anySectionAllowed) {
    return (
      <div className="r-root r-overall">
        <p className="r-supplier-note" role="status">No reports are turned on for your role. Ask the Super Admin to turn them on in Settings → Role Access.</p>
      </div>
    );
  }

  return (
    <div className="r-root r-overall">
      {error ? (
        <p className="r-supplier-note" role="alert">{error}</p>
      ) : (
        <>
          {/* ===== SUMMARY CARDS (click one to open its report) ===== */}
          <div className="r-kpi-grid">
            {cards.map((card) => (
              <div
                key={card.key}
                className="r-kpi-card r-clickable"
                title={`Click to open the ${sectionByKey.get(card.report)?.title || 'report'}`}
                {...clickableProps(opener(card.report), sectionByKey.get(card.report)?.title || card.label)}
              >
                <div className="r-kpi-label">{card.label}</div>
                <div className="r-kpi-value">{firstLoad ? '…' : card.value}</div>
                <div className="r-kpi-sub">{card.sub}</div>
              </div>
            ))}
          </div>

          {/* ===== CHARTS (click one to open its report) ===== */}
          {!(report?.stockMovement || fastSlow) && fullExport}
          {(report?.stockMovement || fastSlow) && (
            <div className="r-overall-charts" ref={fillChartsToBottom}>
              <div className="r-overall-left">
                {report?.stockMovement && (
                  <MovementChartCard rows={movementRows} loading={firstLoad} onOpen={opener('stockMovement')} />
                )}
                {fullExport}
              </div>
              {fastSlow && (
                <div className="r-fs-grid r-overall-fs">
                  <MovementBars
                    title={`Fast-Moving (last ${fastSlow.windowDays || 90} days)`}
                    items={fastSlow.fast || []}
                    tone="fast"
                    emptyText={firstLoad ? 'Loading…' : 'No sales recorded in this period.'}
                    onOpen={opener('fastSlowMoving')}
                  />
                  <MovementBars
                    title={`Slow-Moving (last ${fastSlow.windowDays || 90} days)`}
                    items={fastSlow.slow || []}
                    tone="slow"
                    emptyText={firstLoad ? 'Loading…' : 'No in-stock products to compare.'}
                    onOpen={opener('fastSlowMoving')}
                  />
                </div>
              )}
            </div>
          )}
        </>
      )}

      {openSection && (
        <ReportModal section={openSection} canExport={canExport} onClose={() => setOpenKey(null)} />
      )}
    </div>
  );
}

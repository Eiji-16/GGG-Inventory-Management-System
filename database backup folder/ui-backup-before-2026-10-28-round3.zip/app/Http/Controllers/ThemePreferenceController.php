<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

/**
 * PUT /profile/theme — the signed-in user's own Appearance theme.
 *
 * Saved on the account (not the browser), so one user's choice never
 * changes the theme for anyone else, even on a shared computer.
 */
class ThemePreferenceController extends Controller
{
    public function update(Request $request): JsonResponse
    {
        $data = $request->validate([
            'theme' => ['required', 'string', Rule::in(User::THEMES)],
        ]);

        $request->user()->forceFill(['theme' => $data['theme']])->save();

        return response()->json(['theme' => $data['theme']]);
    }
}

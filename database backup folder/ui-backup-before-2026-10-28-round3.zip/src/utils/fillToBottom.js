import { useCallback, useRef } from 'react';

/* ===== FILL TO BOTTOM =====
   Makes a table box stretch down to the bottom of the page area, so there is
   no empty space under it (it still scrolls inside when there are many rows).

   How: measure where the box starts inside the scrolling page area
   (.main-content-window) and give it the rest of that area's height, minus a
   small gap. It re-measures when the window is resized, or when something
   above or below the table appears or disappears (an error banner, the page
   buttons).

   Phones (900px wide or less) keep their normal card list, so nothing is
   changed there. */
const DESKTOP = '(min-width: 901px)';
const MIN_HEIGHT = 240;

export default function useFillToBottom(gap = 12) {
  const cleanupRef = useRef(null);

  return useCallback((element) => {
    cleanupRef.current?.();
    cleanupRef.current = null;
    if (!element || typeof window === 'undefined') return;

    let frame = 0;
    const apply = () => {
      frame = 0;
      const area = element.closest('.main-content-window');
      // Hidden page (another menu is open) or phone layout: leave it alone.
      if (!area || element.offsetParent === null || !window.matchMedia(DESKTOP).matches) {
        element.style.height = '';
        element.style.maxHeight = '';
        return;
      }
      const areaBox = area.getBoundingClientRect();
      const top = element.getBoundingClientRect().top - areaBox.top + area.scrollTop;
      // Leave room for what sits under the table (e.g. the page buttons) and
      // for the bottom padding of the box around it.
      let below = 0;
      for (let next = element.nextElementSibling; next; next = next.nextElementSibling) {
        const style = window.getComputedStyle(next);
        if (style.position === 'fixed' || style.position === 'absolute' || style.display === 'none') continue;
        below += next.offsetHeight + parseFloat(style.marginTop || 0) + parseFloat(style.marginBottom || 0);
      }
      const parent = element.parentElement;
      if (parent) {
        const style = window.getComputedStyle(parent);
        below += parseFloat(style.paddingBottom || 0) + parseFloat(style.borderBottomWidth || 0);
      }
      const height = Math.max(MIN_HEIGHT, Math.floor(area.clientHeight - top - below - gap));
      if (element.style.height !== `${height}px`) {
        element.style.height = `${height}px`;
        element.style.maxHeight = 'none';
      }
    };
    const schedule = () => {
      if (!frame) frame = window.requestAnimationFrame(apply);
    };

    schedule();
    window.addEventListener('resize', schedule);
    const observer = typeof ResizeObserver === 'function' ? new ResizeObserver(schedule) : null;
    const area = element.closest('.main-content-window');
    if (observer) {
      if (area) observer.observe(area);
      // The box's parent changes size when a banner or toolbar row appears.
      if (element.parentElement) observer.observe(element.parentElement);
    }

    cleanupRef.current = () => {
      window.removeEventListener('resize', schedule);
      observer?.disconnect();
      if (frame) window.cancelAnimationFrame(frame);
    };
  }, [gap]);
}

import React, { useState, useEffect, useMemo } from 'react';
import { Download, FileText, Search, RefreshCw } from 'lucide-react';
import './reports.css';
import exportReportWorkbook, { printReportPdf } from '../../utils/exportReportWorkbook';
import { useCurrency } from '../../CurrencyContext';

/* ===== REPORTS & ANALYTICS: ONE OVERALL REPORT =====
   The whole page is one comprehensive report of the system's data (no tabs).
   It is built from /api/reports:
     1. Key totals (cards) at the top.
     2. Two charts: weekly Stock In vs Stock Out, and fast vs slow moving products.
     3. One section per report: Stock Summary, Stock Movement, Top Moving,
        Fast & Slow Moving, Demand Forecast, Economic Order Quantity
        Calculator, Inventory Aging and Reorder Point.
   One search box filters every section. Export PDF / Export Excel puts every
   section (all rows) into one file.
   Role Access (Settings) still decides which sections a role can see: the
   server leaves hidden sections out of /api/reports. */

/* Status/urgency/confidence → badge colour. */
const BADGE = {
  'In Stock': 'r-badge-good', Healthy: 'r-badge-good', High: 'r-badge-good',
  'Low Stock': 'r-badge-bad', Critical: 'r-badge-bad', Low: 'r-badge-warn',
  'Out of Stock': 'r-badge-bad', 'Slow Mover': 'r-badge-bad',
  'Fast-Moving': 'r-badge-good', 'Slow-Moving': 'r-badge-bad',
  Aging: 'r-badge-warn', Watch: 'r-badge-warn', Medium: 'r-badge-warn', Unknown: 'r-badge-warn',
};
const Badge = ({ label }) => (
  <span className={`r-badge ${BADGE[label] || 'r-badge-warn'}`}><span className="r-dot" />{label}</span>
);

/* Shared empty/loading row. */
const EmptyRow = ({ cols, text }) => (
  <tr><td colSpan={cols} style={{ textAlign: 'center', padding: '18px', color: 'var(--text-muted, #888)' }}>{text}</td></tr>
);

const sumBy = (rows, key) => rows.reduce((total, row) => total + (Number(row[key]) || 0), 0);

/* ===== CHART: weekly Stock In vs Stock Out (Bar / Line) ===== */
function MovementLineChart({ rows, maxVal }) {
  const width = 600;
  const height = 200;
  const pad = { top: 12, right: 12, bottom: 24, left: 12 };
  const innerW = width - pad.left - pad.right;
  const innerH = height - pad.top - pad.bottom;
  const x = (i) => pad.left + (rows.length === 1 ? innerW / 2 : (i / (rows.length - 1)) * innerW);
  const y = (v) => pad.top + innerH - (v / maxVal) * innerH;
  const path = (key) => rows.map((r, i) => `${i === 0 ? 'M' : 'L'}${x(i).toFixed(1)},${y(r[key]).toFixed(1)}`).join(' ');

  return (
    <svg className="r-line-chart" viewBox={`0 0 ${width} ${height}`} role="img" aria-label="Weekly stock in and stock out line chart">
      <line x1={pad.left} x2={width - pad.right} y1={pad.top + innerH} y2={pad.top + innerH} className="r-line-axis" />
      <path d={path('in')} className="r-line r-line-in" />
      <path d={path('out')} className="r-line r-line-out" />
      {rows.map((r, i) => (
        <g key={r.weekStart || i}>
          <circle cx={x(i)} cy={y(r.in)} r="3.5" className="r-line-dot r-line-in"><title>{`Week of ${r.period}: +${r.in} in`}</title></circle>
          <circle cx={x(i)} cy={y(r.out)} r="3.5" className="r-line-dot r-line-out"><title>{`Week of ${r.period}: −${r.out} out`}</title></circle>
          <text x={x(i)} y={height - 6} textAnchor="middle" className="r-line-label">{r.period}</text>
        </g>
      ))}
    </svg>
  );
}

function MovementChartCard({ rows, loading }) {
  const [chartType, setChartType] = useState('bar');
  const maxVal = Math.max(1, ...rows.map((r) => Math.max(r.in, r.out)));
  return (
    <div className="r-chart-card r-overall-chart">
      <div className="r-chart-card-head">
        <h3>Stock In vs Stock Out — last {rows.length || 8} weeks</h3>
        <div className="r-toggle-group">
          <button type="button" className={chartType === 'bar' ? 'active' : ''} onClick={() => setChartType('bar')}>Bar</button>
          <button type="button" className={chartType === 'line' ? 'active' : ''} onClick={() => setChartType('line')}>Line</button>
        </div>
      </div>
      {rows.length === 0 ? (
        <div className="r-chart-placeholder">{loading ? 'Loading…' : 'No movement data yet.'}</div>
      ) : chartType === 'line' ? (
        <MovementLineChart rows={rows} maxVal={maxVal} />
      ) : (
        <div className="r-mini-chart">
          {rows.map((r, i) => (
            <div className="r-mini-col" key={r.weekStart || i} title={`Week of ${r.period}: +${r.in} in / −${r.out} out`}>
              <div className="r-mini-bars">
                <span className="r-mini-bar r-mini-in" style={{ height: `${(r.in / maxVal) * 100}%` }} />
                <span className="r-mini-bar r-mini-out" style={{ height: `${(r.out / maxVal) * 100}%` }} />
              </div>
              <span className="r-mini-label">{r.period}</span>
            </div>
          ))}
        </div>
      )}
      <div className="r-chart-legend">
        <span><i className="r-legend-swatch r-mini-in" /> Stock In</span>
        <span><i className="r-legend-swatch r-mini-out" /> Stock Out</span>
      </div>
    </div>
  );
}

/* ===== CHART: fast vs slow moving products (horizontal bars) ===== */
function MovementBars({ title, items, tone, emptyText }) {
  const max = Math.max(1, ...items.map((item) => item.unitsSold));
  return (
    <div className="r-chart-card r-fs-card r-overall-chart">
      <div className="r-chart-card-head"><h3>{title}</h3></div>
      {items.length === 0 ? (
        <div className="r-fs-empty">{emptyText}</div>
      ) : (
        <ul className="r-fs-list">
          {items.map((item) => (
            <li key={item.productId || item.product} className="r-fs-row">
              <span className="r-fs-name" title={item.product}>{item.product}</span>
              <span className="r-fs-track">
                <span className={`r-fs-bar r-fs-${tone}`} style={{ width: `${Math.max(2, (item.unitsSold / max) * 100)}%` }} />
              </span>
              <span className="r-fs-value">{item.unitsSold}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

/* ===== SECTIONS (the same rows go on screen and into the export) ===== */
function buildSections(report, formatCurrency) {
  const sections = [];
  const add = (title, note, headers, rows, emptyText) => sections.push({ title, note, headers, rows, emptyText });

  if (report?.stockSummary) {
    add('Stock Summary', 'Current stock level, value and status of every product. Value uses the latest Stock In price.',
      ['Product', 'Category', 'Stock', 'Unit Cost', 'Value', 'Status'],
      (report.stockSummary.rows || []).map((r) => [
        r.product, r.category, r.stock,
        r.unitCost != null ? formatCurrency(r.unitCost) : '—',
        r.value != null ? formatCurrency(r.value) : '—',
        r.status,
      ]), 'No products found.');
  }
  if (report?.stockMovement) {
    add('Stock Movement', 'Units in and out per week (last 8 weeks, Monday start). Corrections are not included.',
      ['Week of', 'Stock In', 'Stock Out', 'Net Change'],
      (report.stockMovement.rows || []).map((r) => [r.period, r.in, r.out, `${r.net >= 0 ? '+' : ''}${r.net}`]),
      'No movements recorded yet.');
  }
  if (report?.topMoving) {
    add('Top Moving Products', 'Ranked by units sold (Stock Out). Sales Value uses the selling price recorded on each sale.',
      ['Rank', 'Product', 'Units Sold', 'Sales Value'],
      (report.topMoving.rows || []).map((r) => [r.rank, `${r.product}${r.deleted ? ' (deleted)' : ''}`, r.unitsSold, formatCurrency(r.value)]),
      'No sales recorded yet.');
  }
  if (report?.fastSlowMoving) {
    const days = report.fastSlowMoving.windowDays || 90;
    add('Fast & Slow Moving Products', `Units sold (Stock Out) in the last ${days} days.`,
      ['Movement', 'Rank', 'Product', 'Category', `Units Sold (${days} days)`, 'Current Stock'],
      (report.fastSlowMoving.rows || []).map((r) => [r.movement, r.rank, r.product, r.category, r.unitsSold, r.stock]),
      'No products to rank yet.');
  }
  if (report?.demandForecast) {
    add('Demand Forecast Summary', "Next month's forecast: 3-month Weighted Moving Average plus any active seasonal event.",
      ['Product', 'Current Stock', 'Forecasted Demand', 'Suggested Reorder', 'Confidence'],
      (report.demandForecast.rows || []).map((r) => [
        r.product, r.currentStock,
        `${r.forecastedDemand}${r.adjustmentPct ? ` (${r.adjustmentPct > 0 ? '+' : ''}${r.adjustmentPct}%)` : ''}`,
        r.suggestedReorder, r.confidence,
      ]), 'No completed month of sales yet — record Stock Out in Stock Control or add Past Sales in Forecasting.');
  }
  if (report?.autoCalculator) {
    add('Economic Order Quantity Calculator Summary', 'Every Economic Order Quantity calculation logged to date.',
      ['Product', 'Product ID', 'Formula', 'Demand Source', 'Annual Demand', 'Result', 'Computed By', 'Date Computed'],
      (report.autoCalculator.rows || []).map((r) => [
        r.product || '—', r.productId || '—',
        r.formula === 'EOQ' ? 'Economic Order Quantity' : r.formula,
        r.demandSource === 'forecast' ? 'Forecast' : 'Historical',
        r.annualDemand != null ? `${Number(r.annualDemand).toLocaleString('en-PH')} units/year` : '—',
        r.result != null
          ? `${r.formula === 'EOQ'
            ? (r.recommendedOrderQuantity ?? Math.round(Number(r.result))).toLocaleString('en-PH')
            : r.result} ${r.unit || ''}`.trim()
          : '—',
        r.by || '—', r.date,
      ]), 'No calculations logged yet — use the Economic Order Quantity Calculator.');
  }
  if (report?.inventoryAging) {
    add('Inventory Aging Report', 'Days since the latest Stock In (estimated from the creation date if there is none). Over 60 days = Aging, over 120 = Slow Mover.',
      ['Product', 'Days in Stock', 'Stock Level', 'Status'],
      (report.inventoryAging.rows || []).map((r) => [
        r.product,
        r.daysInStock == null ? '—' : `${r.daysInStock}${r.ageEstimated ? ' (est.)' : ''}`,
        r.stock, r.status,
      ]), 'No stock on hand to age.');
  }
  if (report?.reorderPoint) {
    add('Reorder Point Report', 'Products at or below their reorder point (safety stock + daily sales × lead time).',
      ['Product', 'Current Stock', 'Reorder Point (Low at)', 'Critical at', 'Urgency'],
      (report.reorderPoint.rows || []).map((r) => [
        r.product, r.currentStock, `${r.reorderPoint}${r.mode === 'manual' ? ' (manual)' : ''}`, r.criticalPoint ?? '—', r.urgency,
      ]), 'All products are above their reorder point.');
  }
  return sections;
}

/* ===== KEY TOTALS (cards at the top) ===== */
function buildTotals(report, formatCurrency) {
  const totals = [];
  const kpis = report?.stockSummary?.kpis;
  if (kpis) {
    totals.push({ label: 'Products', value: Number(kpis.productCount || 0).toLocaleString(), sub: `${Number(kpis.totalStock || 0).toLocaleString()} units in stock` });
    totals.push({
      label: 'Inventory Value',
      value: formatCurrency(kpis.inventoryValue),
      sub: `at latest Stock In price${kpis.unpricedProducts ? ` · ${kpis.unpricedProducts} without a price` : ''}`,
    });
    totals.push({ label: 'Low / Out of Stock', value: `${kpis.lowStock || 0} / ${kpis.outOfStock || 0}`, sub: 'products needing attention' });
  }
  if (report?.stockMovement) {
    const rows = report.stockMovement.rows || [];
    totals.push({ label: 'Units Sold', value: sumBy(rows, 'out').toLocaleString(), sub: `last ${rows.length || 8} weeks · ${sumBy(rows, 'in').toLocaleString()} received` });
  }
  if (report?.demandForecast) {
    const rows = report.demandForecast.rows || [];
    totals.push({ label: 'Forecast Next Month', value: Math.round(sumBy(rows, 'forecastedDemand')).toLocaleString(), sub: `units across ${rows.length} product${rows.length === 1 ? '' : 's'}` });
  }
  if (report?.reorderPoint) {
    totals.push({ label: 'To Reorder', value: (report.reorderPoint.rows || []).length.toLocaleString(), sub: 'at or below reorder point' });
  }
  return totals;
}

/* refreshKey changes whenever stock or products change elsewhere; isActive is
   true while the Reports page is on screen. The page stays mounted in the
   background, so it reloads on either. canTab(key) = Role Access for each
   report section; canExport = may export. */
export default function ReportsAnalyticsDesign({ safetyStock, refreshKey = 0, isActive = true, canTab = () => true, canExport = true }) {
  const { formatCurrency } = useCurrency();
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [exportError, setExportError] = useState('');
  const [reloadCount, setReloadCount] = useState(0);
  const [query, setQuery] = useState('');

  const anySectionAllowed = ['stock_summary', 'stock_movement', 'top_moving', 'fast_slow', 'demand_forecast', 'order_quantity', 'inventory_aging', 'reorder_point']
    .some((key) => canTab(key));

  useEffect(() => {
    if (!isActive) return undefined;
    let active = true;
    setLoading(true);
    setError('');
    fetch('/api/reports', { headers: { Accept: 'application/json' }, cache: 'no-store' })
      .then((r) => { if (!r.ok) throw new Error(`Could not load reports (${r.status}).`); return r.json(); })
      .then((data) => { if (active) setReport(data); })
      .catch((e) => { if (active) setError(e.message || 'Could not load reports.'); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [safetyStock, refreshKey, isActive, reloadCount]);

  const sections = useMemo(() => buildSections(report, formatCurrency), [report, formatCurrency]);
  const totals = useMemo(() => buildTotals(report, formatCurrency), [report, formatCurrency]);

  /* One search for every section: keep rows where any cell contains the text. */
  const search = query.trim().toLowerCase();
  const shownSections = useMemo(() => sections.map((section) => ({
    ...section,
    rows: search
      ? section.rows.filter((row) => row.some((cell) => String(cell ?? '').toLowerCase().includes(search)))
      : section.rows,
  })), [sections, search]);

  const firstLoad = loading && !report;   // keep old numbers on screen while refreshing
  const updatedAt = report?.generatedAt
    ? new Date(report.generatedAt).toLocaleTimeString('en-PH', { hour: 'numeric', minute: '2-digit' })
    : null;

  /* ===== EXPORT: every section, all (matching) rows, one file ===== */
  const title = 'Overall Inventory Report';
  const subtitle = 'All system data in one report: stock, movements, sales, forecasts, order quantities, aging and reorder needs';
  const exportSections = shownSections.map((section) => ({
    title: section.title,
    headers: section.headers,
    rows: section.rows.map((row) => row.map((cell) => (cell == null ? '' : cell))),
  }));
  const summary = totals.map(({ label, value }) => ({ label, value }));
  const scope = search
    ? `Rows matching "${query.trim()}" in every report section you have access to.`
    : 'Every report section you have access to, with all of its rows, as of the time of export.';
  const note = exportSections.every((section) => section.rows.length === 0) ? 'No report rows were available at the time of export.' : '';

  const handleExcel = async () => {
    setExportError('');
    try {
      await exportReportWorkbook({
        title,
        subtitle,
        fileName: 'overall-inventory-report',
        sections: exportSections,
        summary,
        scope,
        note,
        columnWidths: Array.from({ length: Math.max(1, ...exportSections.map((s) => s.headers.length)) }, () => 24),
      });
    } catch (exportFailure) {
      console.error('Could not export the overall report:', exportFailure);
      setExportError('Export failed. Please try again.');
    }
  };

  const handlePdf = () => {
    setExportError('');
    try {
      const opened = printReportPdf({ title, subtitle, summary, sections: exportSections, scope, note });
      if (!opened) throw new Error('Allow pop-ups for this site to export the PDF.');
    } catch (exportFailure) {
      console.error('Could not export the overall report as PDF:', exportFailure);
      setExportError(exportFailure.message || 'PDF export failed. Please try again.');
    }
  };

  const movementRows = report?.stockMovement?.rows || [];
  const fastSlow = report?.fastSlowMoving;

  return (
    <div className="r-root r-overall">
      {/* ===== HEADER: title, search, refresh, export ===== */}
      <div className="r-overall-top">
        <div className="r-panel-title">
          <h2>{title}</h2>
          <p>{subtitle}</p>
          {exportError && <p role="alert">{exportError}</p>}
        </div>
        <div className="r-overall-actions">
          <label className="r-overall-search">
            <Search size={13} aria-hidden="true" />
            <input
              type="search"
              placeholder="Search all sections…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              aria-label="Search every report section"
            />
          </label>
          <button
            type="button"
            className="r-refresh-btn"
            onClick={() => setReloadCount((n) => n + 1)}
            disabled={loading}
            title={`Updates automatically when data changes${updatedAt ? ` · last updated ${updatedAt}` : ''}. Click to reload now.`}
          >
            {!loading && <span className="r-live-dot" aria-hidden="true" />}
            <RefreshCw size={12} className={loading ? 'r-spin' : ''} />
            {loading ? 'Updating…' : updatedAt ? `Live · updated ${updatedAt}` : 'Refresh'}
          </button>
          {canExport && (
            <>
              <button className="r-export-btn" type="button" onClick={handlePdf} disabled={firstLoad}>
                <FileText size={13} /> Export PDF
              </button>
              <button className="r-export-btn" type="button" onClick={handleExcel} disabled={firstLoad}>
                <Download size={13} /> Export Excel
              </button>
            </>
          )}
        </div>
      </div>

      {!anySectionAllowed ? (
        <p className="r-supplier-note" role="status">No report sections are turned on for your role. Ask the Super Admin to turn them on in Settings → Role Access.</p>
      ) : error ? (
        <p className="r-supplier-note" role="alert">{error}</p>
      ) : (
        <>
          {/* ===== KEY TOTALS ===== */}
          {totals.length > 0 && (
            <div className="r-kpi-row">
              {totals.map((item) => (
                <div className="r-kpi-card" key={item.label}>
                  <div className="r-kpi-label">{item.label}</div>
                  <div className="r-kpi-value">{firstLoad ? '…' : item.value}</div>
                  <div className="r-kpi-sub">{item.sub}</div>
                </div>
              ))}
            </div>
          )}

          {/* ===== CHARTS ===== */}
          {(report?.stockMovement || fastSlow) && (
            <div className="r-overall-charts">
              {report?.stockMovement && <MovementChartCard rows={movementRows} loading={firstLoad} />}
              {fastSlow && (
                <div className="r-fs-grid r-overall-fs">
                  <MovementBars
                    title={`Fast-Moving (last ${fastSlow.windowDays || 90} days)`}
                    items={fastSlow.fast || []}
                    tone="fast"
                    emptyText={firstLoad ? 'Loading…' : 'No sales recorded in this period.'}
                  />
                  <MovementBars
                    title={`Slow-Moving (last ${fastSlow.windowDays || 90} days)`}
                    items={fastSlow.slow || []}
                    tone="slow"
                    emptyText={firstLoad ? 'Loading…' : 'No in-stock products to compare.'}
                  />
                </div>
              )}
            </div>
          )}

          {/* ===== EVERY REPORT SECTION ===== */}
          {shownSections.map((section) => (
            <section className="r-overall-section" key={section.title} aria-label={section.title}>
              <div className="r-overall-head">
                <div>
                  <h3>{section.title}</h3>
                  <p>{section.note}</p>
                </div>
                <span className="r-overall-count">
                  {firstLoad ? '' : `${section.rows.length.toLocaleString()} ${section.rows.length === 1 ? 'row' : 'rows'}`}
                </span>
              </div>
              <div className="r-table-card r-overall-table">
                <table className="r-table">
                  <thead>
                    <tr>{section.headers.map((header) => <th key={header}>{header}</th>)}</tr>
                  </thead>
                  <tbody>
                    {firstLoad ? <EmptyRow cols={section.headers.length} text="Loading…" />
                      : section.rows.length === 0 ? <EmptyRow cols={section.headers.length} text={search ? 'No rows match your search.' : section.emptyText} />
                      : section.rows.map((row, rowIndex) => (
                        <tr key={rowIndex}>
                          {row.map((cell, cellIndex) => (
                            <td key={cellIndex}>{BADGE[cell] ? <Badge label={cell} /> : cell}</td>
                          ))}
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </section>
          ))}
        </>
      )}
    </div>
  );
}

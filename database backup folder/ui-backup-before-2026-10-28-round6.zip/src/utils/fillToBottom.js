import { useCallback, useRef } from 'react';

/* ===== FILL TO BOTTOM =====
   Makes a table box stretch down to the bottom of the page area, so there is
   no empty space under it (it still scrolls inside when there are many rows).

   How: measure where the box starts inside the scrolling page area
   (.main-content-window) and give it the rest of that area's height, minus a
   small gap. It re-measures when the window is resized, or when something
   above or below the table appears or disappears (an error banner, the page
   buttons).

   shrink: true = the box is only as tall as its rows, up to the bottom of
   the page (for short lists like Suppliers, so no empty space inside it).

   Phones (900px wide or less) keep their normal card list, so nothing is
   changed there. */
const DESKTOP = '(min-width: 901px)';
const MIN_HEIGHT = 240;

export default function useFillToBottom(gap = 12, { shrink = false } = {}) {
  const cleanupRef = useRef(null);

  return useCallback((element) => {
    cleanupRef.current?.();
    cleanupRef.current = null;
    if (!element || typeof window === 'undefined') return;

    let frame = 0;
    const apply = () => {
      frame = 0;
      const area = element.closest('.main-content-window');
      // Hidden page (another menu is open) or phone layout: leave it alone.
      if (!area || element.offsetParent === null || !window.matchMedia(DESKTOP).matches) {
        element.style.height = '';
        element.style.maxHeight = '';
        return;
      }
      const areaBox = area.getBoundingClientRect();
      const top = element.getBoundingClientRect().top - areaBox.top + area.scrollTop;
      // Leave room for everything below the table inside the page area: the
      // things after it (e.g. the page buttons) and the bottom padding /
      // borders / margins of each box around it, up to the page area itself.
      let below = 0;
      for (let node = element; node && node !== area; node = node.parentElement) {
        for (let next = node.nextElementSibling; next; next = next.nextElementSibling) {
          const style = window.getComputedStyle(next);
          if (style.position === 'fixed' || style.position === 'absolute' || style.display === 'none') continue;
          below += next.offsetHeight + parseFloat(style.marginTop || 0) + parseFloat(style.marginBottom || 0);
        }
        const own = window.getComputedStyle(node);
        below += parseFloat(own.marginBottom || 0);
        const parent = node.parentElement;
        if (parent) {
          const style = window.getComputedStyle(parent);
          below += parseFloat(style.paddingBottom || 0) + parseFloat(style.borderBottomWidth || 0);
        }
      }
      const height = Math.max(MIN_HEIGHT, Math.floor(area.clientHeight - top - below - gap));
      if (shrink) {
        // As tall as its rows, but never past the bottom of the page.
        if (element.style.maxHeight !== `${height}px`) {
          element.style.height = '';
          element.style.maxHeight = `${height}px`;
        }
      } else if (element.style.height !== `${height}px`) {
        element.style.height = `${height}px`;
        element.style.maxHeight = 'none';
      }
    };
    const schedule = () => {
      if (!frame) frame = window.requestAnimationFrame(apply);
    };

    schedule();
    window.addEventListener('resize', schedule);
    const observer = typeof ResizeObserver === 'function' ? new ResizeObserver(schedule) : null;
    const area = element.closest('.main-content-window');
    if (observer) {
      if (area) observer.observe(area);
      // The box's parent changes size when a banner or toolbar row appears.
      if (element.parentElement) observer.observe(element.parentElement);
    }

    cleanupRef.current = () => {
      window.removeEventListener('resize', schedule);
      observer?.disconnect();
      if (frame) window.cancelAnimationFrame(frame);
    };
  }, [gap, shrink]);
}
